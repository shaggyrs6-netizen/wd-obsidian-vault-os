---
record_class: system
title: "Start with Codex"
---
# Start with Codex

1. Extract the ZIP into a new folder. Locate the inner **WD Vault OS** folder with HOME.md, START HERE.md and Setup.
2. Open **OPEN START.html** and choose Codex. You do not need a Markdown reader or Obsidian for these steps.
3. In Codex, add a local project for only this folder. In its menu, **Edit project → Add folder** lets you check the attached folder; **Make primary** selects where a new chat starts. Keep other personal folders out of this project.
4. Start a local chat in that project. Do not choose a cloud repository task or assume uploaded files grant access to the originals. Keep normal approval controls; no unrestricted access is required.
5. Send the prompt below. The assistant checks the actual folder and capabilities read-only. If an existing local Node runtime can run the helper against that folder, it shows the exact progress path and asks permission before its first write. Otherwise use the manual saving route.

[Official projects and folder guidance](https://learn.chatgpt.com/docs/projects), checked for 0.2.1 on 13 October. Product names and controls may vary; an actual folder read-back matters more than a label. Existing CLI users may work from the selected directory, but beginners are not required to use a terminal.

## Copyable starting prompt
```text
Please read Setup/Guided setup.md in the selected original WD Vault OS folder. Do not write anything yet. Show the actual connected folder, check your available tools and look for existing progress. State whether you can run the existing helper locally against that original folder, only use connected-folder tools, or only access cloud/uploads. Do not assume a cloud shell reaches my computer. Before any progress write, name the exact full progress location and ask my permission for that location. This permission covers interview progress only; starter notes require a separate preview and explicit approval. Ask the five starting questions one at a time, then ask which optional workflows I want (or just basics), allowing skip, not sure and pause. Save and read back each permitted checkpoint before continuing. Preserve existing answers and edited notes; no silent route change, second interview, overwrite or reset. If safe automatic saving is unavailable, explain the user-saved manual route. Workflow choices only add guide links; do not install Readwise, activate Prism, schedule notes, connect accounts, take external actions or edit governing files. Introduce Obsidian after the first useful saved result.
```

For a fictional test, tick the rehearsal option on the HTML page or append:
```text
This is a fictional rehearsal, not my real commitments. Use rehearsal mode and keep all progress and outputs under Demonstration/Onboarding rehearsal. Before writing, ask permission for the exact rehearsal progress location.
```

## Return in a fresh conversation
Reconnect the same original folder and paste:
```text
Resume Setup/Guided setup.md in the same selected original folder. Begin read-only. Check the saved route, mode, progress permission, all complete checkpoints and any existing outputs. Tell me the next unanswered question or unfinished step. Do not repeat answered or skipped questions. If capability, route, location or permission differs, stop for review and ask before any reconciliation; do not start a second interview. Reuse only an unchanged approved preview. Preserve every existing note and answer.
```
For a rehearsal, append the same fictional-mode sentence. Read-only inspection is allowed by this request; writes still depend on the recorded exact scope. [[Setup/Guided setup]] defines paths. [[Setup/File-tool checkpoint protocol]] explains unavailable tools and manual saving.

Once your first useful note is saved, open [[AFTER SETUP|What to do after setup]]. Obsidian shows the notes; return to this connected Codex chat for writing or research. [[RECENTS|Recent notes]] helps you find files Codex made.

---
record_class: "system"
title: "Continuity desk"
---
# Continuity desk

A fresh session needs a project, last confirmed state, a next action and the limits of its authority.


```wd-action
{"action": "handoff", "label": "New handoff"}
```

```wd-view
{"scope": "user", "kind": "handoff"}
```

## Without the plugin
Create a note in `Continuity/` and insert [[System/Templates/Handoff|the handoff template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Sound/Pause after the clipping test]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

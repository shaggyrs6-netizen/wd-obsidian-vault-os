'use strict';
const {Plugin,Modal,Notice,parseYaml,MarkdownRenderChild}=require('obsidian');
// The build embeds the original engine here, so the installed plugin is one readable JS file.
const E=(()=>{const module={exports:{}};
'use strict';

const TYPES = Object.freeze({
  capture: {folder:'Capture', template:'Capture', label:'capture'},
  project: {folder:'Projects', template:'Project', label:'project'},
  decision: {folder:'Projects/Decisions', template:'Decision', label:'decision', project:true},
  knowledge: {folder:'Knowledge', template:'Knowledge', label:'knowledge note'},
  topic: {folder:'Knowledge/Topics', template:'Topic', label:'topic guide'},
  source: {folder:'Sources', template:'Source', label:'source'},
  person: {folder:'People', template:'Person', label:'person'},
  conversation: {folder:'People/Conversations', template:'Conversation', label:'conversation'},
  everyday: {folder:'Everyday', template:'Everyday', label:'everyday note'},
  routine: {folder:'Everyday/Routines', template:'Routine', label:'routine'},
  writing: {folder:'Writing', template:'Writing', label:'writing note'},
  daily: {folder:'Journal/Daily', template:'Daily', label:"today's note", dated:true},
  weekly: {folder:'Journal/Reviews', template:'Weekly', label:'weekly review', dated:true},
  monthly: {folder:'Journal/Reviews', template:'Monthly', label:'monthly review', dated:true},
  handoff: {folder:'Continuity', template:'Handoff', label:'session handoff', project:true},
  verification: {folder:'System/Checks', template:'Verification', label:'verification record'}
});
const DEMO_PREFIX = 'Demonstration/';
function dateKey(now=new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
}
function weekKey(now=new Date()) {
  const d=new Date(now.getFullYear(),now.getMonth(),now.getDate(),12);
  d.setDate(d.getDate()-((d.getDay()+6)%7)); return dateKey(d);
}
function safeTitle(raw) {
  const title=String(raw || '').normalize('NFC').trim();
  if (!title || title.length>100 || /[\x00-\x1f\x7f<>:"/\\|?*\[\]#^{}]/u.test(title) || /[. ]$/.test(title) || title.startsWith('.') || /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(title)) {
    throw new Error('Use 1–100 characters without path separators, brackets or reserved filename characters.');
  }
  return title;
}
function meta(text,parseYaml) {
  const match=String(text).match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  if (!match) return {};
  try { const value=parseYaml(match[1]); return value && typeof value==='object' && !Array.isArray(value)?value:{}; } catch { return {}; }
}
function isUser(path,m) {
  return !path.startsWith(DEMO_PREFIX) && !path.startsWith('System/Templates/') && m.record_class==='user' && m.commitment_scope==='real' && !m.scenario_id;
}
function timestamp(m) {
  const s=m.recorded_at;
  if(typeof s!=='string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:\d\d)$/.test(s))return null;
  const y=Number(s.slice(0,4)),mo=Number(s.slice(5,7)),d=Number(s.slice(8,10));
  const calendar=new Date(Date.UTC(y,mo-1,d));
  if(calendar.getUTCFullYear()!==y||calendar.getUTCMonth()!==mo-1||calendar.getUTCDate()!==d||Number(s.slice(11,13))>23||Number(s.slice(14,16))>59||Number(s.slice(17,19))>59)return null;
  const value=Date.parse(s);return Number.isFinite(value)?value:null;
}
function chronology(records) {
  const handoffs=records.filter(r=>r.meta.kind==='handoff');
  const missing=handoffs.filter(r=>timestamp(r.meta)===null);
  const times=handoffs.map(r=>timestamp(r.meta)).filter(t=>t!==null);
  const tied=new Set(times).size!==times.length;
  return {uncertain:missing.length>0||tied,missing:missing.length,tied};
}
function compareRecords(a,b) {
  const at=timestamp(a.meta),bt=timestamp(b.meta);
  if(at!==null && bt!==null)return bt-at || a.path.localeCompare(b.path);
  if(at!==null)return -1;if(bt!==null)return 1;
  // Legacy dates are displayed, never interpreted as exact chronology.
  return String(b.meta.created||'').localeCompare(String(a.meta.created||'')) || a.path.localeCompare(b.path);
}
function isDemo(path,m) {
  return path.startsWith(DEMO_PREFIX) && m.record_class==='demonstration' && m.commitment_scope==='fictional' && typeof m.scenario_id==='string';
}
function select(records,filter={}) {
  const scope=filter.scope || 'user';
  if (!['user','demonstration'].includes(scope)) throw new Error('Unknown view scope.');
  if (filter.kind && !Object.hasOwn(TYPES,filter.kind)) throw new Error('Unknown record type.');
  return records.filter(r => (scope==='user'?isUser(r.path,r.meta):isDemo(r.path,r.meta))
    && (!filter.kind || r.meta.kind===filter.kind)
    && (!filter.project_id || r.meta.project_id===filter.project_id || (r.meta.kind==='project' && r.meta.record_id===filter.project_id)))
    .sort(compareRecords);
}
function plan(kind,input,template,context={}) {
  if(!Object.hasOwn(TYPES,kind)) throw new Error('Unknown creation action.'); const def=TYPES[kind];
  const now=context.now || new Date();
  const title=safeTitle(kind==='daily'?dateKey(now):kind==='weekly'?`Week of ${weekKey(now)}`:kind==='monthly'?`Month ${dateKey(now).slice(0,7)}`:input.title);
  const project=context.project;
  if(def.project && !project) throw new Error('Choose a real project first.');
  if(project && (!isUser(project.path,project.meta) || project.meta.kind!=='project' || typeof project.meta.record_id!=='string' || !project.meta.record_id)) throw new Error('The selected project is not a classified real project.');
  const id=context.id || globalThis.crypto.randomUUID();
  const path=`${def.folder}/${title}.md`;
  const values={title, input:String(input.input||'Not recorded yet.'), next:String(input.next||'Not decided yet.'), evidence:String(input.evidence||'Not checked.'), blocker:String(input.blocker||'None recorded.'), project_link:project?`[[${project.path.slice(0,-3)}|${project.meta.title || project.path.split('/').pop().slice(0,-3)}]]`:'No project selected.', date:kind==='weekly'?weekKey(now):dateKey(now), project_view:kind==='project'?`\n\`\`\`wd-view\n${JSON.stringify({scope:'user',project_id:id})}\n\`\`\`\n`:''};
  // Read the template as content, never code. Strip its classification and manual-only tail.
  let body=String(template).replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/,'').split('\n<!-- MANUAL-ONLY -->')[0];
  body=body.replace(/\{\{([a-z_]+)\}\}/g,(_,key)=>{if(!(key in values)) throw new Error(`Unknown template field: ${key}`);return values[key];});
  const front={record_class:'user',commitment_scope:'real',kind,record_id:id,title,created:dateKey(now),recorded_at:now.toISOString(),project_id:kind==='project'?id:(project?.meta.record_id||''),status:kind==='verification'?'unverified':kind==='writing'?'draft':'open'};
  const content=`---\n${Object.entries(front).map(([k,v])=>`${k}: ${JSON.stringify(v)}`).join('\n')}\n---\n${body.trim()}\n`;
  return {path,content,kind,projectPath:project?.path,projectOriginal:project?.content,templatePath:`System/Templates/${def.template}.md`,templateOriginal:template};
}
async function ensureParents(vault,path) {
  const parts=path.split('/');parts.pop();let current='';
  for(const part of parts) {
    current=current?`${current}/${part}`:part;
    if(!vault.getAbstractFileByPath(current)) await vault.createFolder(current);
  }
}
async function createChecked(vault,p) {
  // Only fixed product destinations are accepted, even if called outside the UI.
  const def=TYPES[p.kind];
  if(!Object.hasOwn(TYPES,p.kind) || !p.path.startsWith(`${def.folder}/`) || p.path.slice(def.folder.length+1).includes('/') || p.path!==`${def.folder}/${safeTitle(p.path.slice(def.folder.length+1,-3))}.md`) throw new Error('Invalid destination.');
  if(vault.getAbstractFileByPath(p.path)) throw new Error('A note already exists at this path. Nothing was replaced.');
  if((vault.getMarkdownFiles?.()||[]).some(f=>f.path.normalize('NFC').toLocaleLowerCase('en-US')===p.path.normalize('NFC').toLocaleLowerCase('en-US'))) throw new Error('A note with the same name and different capitalisation exists. Nothing was replaced.');
  if(p.projectPath) {
    const file=vault.getAbstractFileByPath(p.projectPath);
    if(!file || await vault.read(file)!==p.projectOriginal) throw new Error('The project changed after preview. Reopen the form and review the new context.');
  }
  const tf=vault.getAbstractFileByPath(p.templatePath);
  if(!tf || await vault.read(tf)!==p.templateOriginal) throw new Error('The template changed after preview. Reopen the form.');
  await ensureParents(vault,p.path);
  // Vault.create rejects an existing file. No modify/delete API is used here.
  const file=await vault.create(p.path,p.content);
  if(await vault.read(file)!==p.content) throw new Error('Read-back did not match. A file may exist; inspect it before retrying. Nothing was deleted.');
  return file;
}
module.exports={TYPES,dateKey,weekKey,safeTitle,meta,isUser,isDemo,select,plan,createChecked,timestamp,chronology,compareRecords};

return module.exports;})();
function node(parent,tag,text,cls) { const el=parent.ownerDocument.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;parent.appendChild(el);return el; }
function button(parent,label,fn,primary=false) {const b=node(parent,'button',label,primary?'mod-cta':'');b.type='button';b.addEventListener('click',fn);return b;}
class CreateModal extends Modal {
  constructor(app,plugin,kind){super(app);this.plugin=plugin;this.kind=kind;this.input={};this.project=null;this.busy=false;}
  async onOpen(){
    const el=this.contentEl;el.empty();node(el,'h2',`New ${E.TYPES[this.kind].label}`);
    node(el,'p',`Creates one note in ${E.TYPES[this.kind].folder}/. Existing notes are never replaced.`);
    const form=node(el,'form');form.addEventListener('submit',ev=>{ev.preventDefault();this.preview();});
    this.fields=[];
    const details=node(form,'details');node(details,'summary','Add a blocker or evidence (optional)');
    for(const [key,label,multi] of [['title','Name',false],['input','What is this about?',true],['next','Next small action',false],['blocker','What is blocked?',false],['evidence','What has actually been checked?',false]]) {
      if(key==='title' && E.TYPES[this.kind].dated)continue;
      const wrap=node(['blocker','evidence'].includes(key)?details:form,'label',undefined,'wd-field');node(wrap,'span',label);const inp=node(wrap,multi?'textarea':'input');
      inp.value=this.input[key]||'';
      if(!multi)inp.type='text';else inp.rows=3;
      inp.maxLength=key==='title'?100:4000;inp.addEventListener('input',()=>{this.input[key]=inp.value;});this.fields.push(inp);
    }
    form.appendChild(details);
    if(this.kind!=='project')try {
      const records=await this.plugin.records();
      const projects=E.select(records,{kind:'project'});
      const wrap=node(form,'label',undefined,'wd-field');node(wrap,'span',E.TYPES[this.kind].project?'Project (required)':'Project (optional)');
      const picker=node(wrap,'select');const none=node(picker,'option','Choose a project');none.value='';
      for(const p of projects){const option=node(picker,'option',p.meta.title||p.path);option.value=p.path;}
      this.project=projects.find(p=>p.path===this.project?.path)||null;
      picker.value=this.project?.path||'';
      picker.addEventListener('change',()=>{this.project=projects.find(p=>p.path===picker.value)||null;});
      if(!projects.length && E.TYPES[this.kind].project)node(form,'p','Create a project first. Fictional projects are deliberately excluded.');
    }catch(err){node(form,'p',`Could not read projects: ${err.message}`);}
    this.error=node(el,'p','', 'wd-error');
    const actions=node(el,'div',undefined,'wd-actions');button(actions,'Preview note',()=>this.preview(),true);button(actions,'Cancel',()=>this.close());
    this.fields[0]?.focus();
  }
  async preview(){
    if(this.busy)return;
    try{
      const def=E.TYPES[this.kind];const tf=this.app.vault.getAbstractFileByPath(`System/Templates/${def.template}.md`);
      if(!tf)throw new Error('Template is missing. Use System/Manual creation for recovery.');
      const p=E.plan(this.kind,this.input,await this.app.vault.read(tf),{project:this.project});
      const existing=this.app.vault.getAbstractFileByPath(p.path);
      if(existing){
        const m=E.meta(await this.app.vault.read(existing),parseYaml);
        if(def.dated && E.isUser(p.path,m) && m.kind===this.kind){await this.app.workspace.getLeaf(false).openFile(existing);this.close();return;}
        throw new Error('That note already exists. Choose a different name or open it from the file explorer.');
      }
      const el=this.contentEl;el.empty();node(el,'h2','Review before saving');node(el,'p',p.path);node(el,'pre',p.content,'wd-preview');
      const error=node(el,'p','','wd-error');
      const actions=node(el,'div',undefined,'wd-actions');
      const save=button(actions,'Create this note',async()=>{
        if(this.busy)return;this.busy=true;save.disabled=true;
        try{const f=await E.createChecked(this.app.vault,p);new Notice('Saved and read back.');await this.app.workspace.getLeaf(false).openFile(f);this.close();}
        catch(err){error.textContent=err.message;this.busy=false;save.disabled=false;}
      },true);
      button(actions,'Back',()=>this.onOpen());button(actions,'Cancel',()=>this.close());
    }catch(err){this.error.textContent=err.message;}
  }
  onClose(){this.contentEl.empty();}
}
class InspectModal extends Modal {
  constructor(app,report){super(app);this.report=report;}
  onOpen(){node(this.contentEl,'h2','Demonstration dependency check');node(this.contentEl,'p','Read-only. No files are removed. Review these links before any separately approved removal.');node(this.contentEl,'pre',this.report,'wd-preview');button(this.contentEl,'Close',()=>this.close());}
}
module.exports=class WDActions extends Plugin {
  async onload(){
    const identity=this.app.vault.getAbstractFileByPath('System/Package identity.md');
    if(!identity || !(await this.app.vault.read(identity)).includes('wd_package: wd-vault-os-complete')){new Notice('WD Actions is disabled: this is not a recognised WD Vault OS package.');return;}
    for(const [kind,def] of Object.entries(E.TYPES))this.addCommand({id:`new-${kind}`,name:`New ${def.label}`,callback:()=>this.openCreate(kind)});
    this.addCommand({id:'open-home',name:'Open home',callback:()=>this.app.workspace.openLinkText('HOME','',false)});
    this.addCommand({id:'inspect-demonstration-links',name:'Inspect links to demonstrations (read-only)',callback:()=>this.inspectDemo()});
    this.registerMarkdownCodeBlockProcessor('wd-action',(source,el,ctx)=>{
      try{
        const spec=JSON.parse(source);if(!Object.hasOwn(E.TYPES,spec.action))throw new Error('Unknown action.');
        if(ctx.sourcePath.startsWith(E.DEMO_PREFIX||'Demonstration/'))throw new Error('Create real notes from a user section, not from a fictional record.');
        button(el,typeof spec.label==='string'?spec.label:`New ${E.TYPES[spec.action].label}`,()=>this.openCreate(spec.action),true);
      }catch(err){node(el,'p',`Action unavailable: ${err.message} Use the command palette or System/Manual creation.`);}
    });
    this.registerMarkdownCodeBlockProcessor('wd-view',async(source,el,ctx)=>{
      let filter;try{filter=JSON.parse(source);E.select([],filter);}catch(err){node(el,'p',`View unavailable: ${err.message}`);return;}
      const child=new MarkdownRenderChild(el);ctx.addChild(child);let serial=0;
      const render=async()=>{
        const ticket=++serial;
        try{
          const records=E.select(await this.records(),filter);if(ticket!==serial)return;el.replaceChildren();
          node(el,'p',filter.scope==='demonstration'?'FICTIONAL DEMONSTRATION · no real commitments':'Your records · fictional examples excluded','wd-scope');
          const order=E.chronology(records);
          if(order.uncertain)node(el,'p','Handoff order needs review: some records lack an exact timestamp or share one. Timed records appear first; filename order is not proof of the latest state.','wd-error');
          if(!records.length){node(el,'p','Nothing recorded here yet. Use the creation action above, or follow the manual route below.');return;}
          const list=node(el,'ul');for(const r of records){const li=node(list,'li');const a=node(li,'a',r.meta.title||r.path);a.href='#';a.addEventListener('click',ev=>{ev.preventDefault();this.app.workspace.openLinkText(r.path,ctx.sourcePath,false);});node(li,'span',` · ${r.meta.status||'unclassified'}${r.meta.kind==='handoff'?' · '+(E.timestamp(r.meta)!==null?r.meta.recorded_at:'time unknown; '+(r.meta.created||'date unknown')):''}`,'wd-muted');}
        }catch(err){if(ticket===serial){el.replaceChildren();node(el,'p',`Could not read this view: ${err.message}`);}}
      };
      for(const event of ['create','modify','delete','rename'])child.registerEvent(this.app.vault.on(event,render));await render();
    });
  }
  openCreate(kind){new CreateModal(this.app,this,kind).open();}
  async records(){
    const records=[];
    for(const file of this.app.vault.getMarkdownFiles()){
      if(file.path.startsWith('System/Templates/'))continue;
      const content=await this.app.vault.read(file);records.push({path:file.path,content,meta:E.meta(content,parseYaml)});
    }
    return records;
  }
  async inspectDemo(){
    try{
      const records=await this.records();const demos=records.filter(r=>r.path.startsWith('Demonstration/'));
      const hits=[];
      for(const r of records.filter(r=>!r.path.startsWith('Demonstration/'))){
        const cache=this.app.metadataCache.getFileCache(this.app.vault.getAbstractFileByPath(r.path));
        for(const l of [...(cache?.links||[]),...(cache?.embeds||[])]){
          const dest=this.app.metadataCache.getFirstLinkpathDest(l.link,r.path);
          if(dest?.path.startsWith('Demonstration/'))hits.push(`${r.path} → ${dest.path}`);
        }
      }
      new InspectModal(this.app,`${demos.length} demonstration records.\n\nInbound links found by the current metadata cache:\n${hits.join('\n')||'None reported.'}\n\nThis is not an automatic deletion approval. Check unresolved links and plain-text references manually too. See System/Remove demonstrations.`).open();
    }catch(err){new Notice(`Inspection failed: ${err.message}`);}
  }
};

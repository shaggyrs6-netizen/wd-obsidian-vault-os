---
record_class: system
title: "Choose your starting route"
---
# Choose your starting route

You do not need Obsidian yet. Open [OPEN START.html](OPEN%20START.html) in a browser: the essential steps, starting prompt and manual alternative are all on that page.

- [[START WITH CLAUDE|Start with Claude]]
- [[START WITH CODEX|Start with Codex]]
- [[CONTINUE MANUALLY|Continue manually without AI]]

The assistant starts read-only. It checks the selected original folder, names exactly where progress would be saved and asks permission. Approval to save interview progress is separate from approval to create the four starter notes.

Automatic saving needs the existing local helper running against your actual folder. Connected-folder tools without the required guarantees can guide manual saving; a cloud download is not a local save. No installation or wider permissions are required by this package.

The whole vault remains available through [[HOME]]. [[Setup/Operator walkthrough|Lee's short fictional walkthrough]] includes a pause after question two. [[Setup/What setup actually does]] · [[Setup/Documentation sources]].

After your first notes are saved, open [[AFTER SETUP|What to do after setup]]. [[RECENTS|Recent notes]] helps you find anything you just made.

---
record_class: system
title: "What setup actually does"
---
# What setup actually does

The assistant asks and interprets. The existing optional local helper records authorised progress and creates separately approved notes. WD Actions supplies note buttons in Obsidian later. None performs the user's actual project.

Supported automatic saving: an existing Node runtime executing the helper on the selected original folder. Read-only status → exact-location permission → exclusive checkpoint + read-back → six answers → exact preview → separate starter-note approval → exclusive output creation + read-back.

Connected-folder tools without that route provide read/guidance and user-saved manual continuation only. A check followed by a generic write is not described as atomic. Cloud outputs/downloads are not local saves.

No new installer, account connection or migration layer. Older or conflicting progress stops for explicit review. Manual first use needs no IDs or properties. Real app connection, fresh AI sessions, Obsidian use and beginner usability remain unverified until observed.

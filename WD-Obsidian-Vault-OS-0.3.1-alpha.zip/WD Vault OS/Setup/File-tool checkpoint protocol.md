---
record_class: system
title: "Connected-folder tools: supported limits"
---
# Connected-folder tools: supported limits

## This route no longer promises automatic saving
The September feedback reported that Claude's connected-folder tools lacked exclusive creation. Their current capabilities must be inspected, not assumed. A general write tool plus an existence check is **not atomic exclusive creation** and does not meet this package's automatic-save guarantee.

This revision supports automatic saving only through the existing helper running against the selected original local filesystem. It does not require installing Node, using Claude Code or weakening permissions. A cloud shell with Node is not proof of access to that filesystem.

## Supported alternative: AI guidance, user saves
1. Explain that automatic saving is unavailable and why. Ask whether the user wants manual saving while the assistant asks the same five short questions, followed by the optional workflow choice.
2. Identify the exact workbook: `MY FIRST NOTES.md` for real work, or `Demonstration/Onboarding rehearsal/Manual notes.md` for fictional testing. The user—not the assistant—edits it. No separate file-tool checkpoint directory is created.
3. If answers already exist in checkpoints or another workbook, read only those authorised records. Show a proposed continuation summary and ask before reconciling anything. Preserve answers, skips, next question and any previous approval. No new interview or automatic migration.
4. Ask one question; the user saves the answer, closes and reopens the file. With connected-folder read access, the assistant can read that exact file back; otherwise label it user-reported. Neither case claims an atomic assistant write.
5. On pause, the user saves a short resume block with the answered/skipped slots and next question. A fresh session reads that same record. If the original file cannot be read, the user may paste their saved summary; identify the reduced evidence.
6. The assistant can preview helpful wording, but does not promise creation of three local starter notes. The workbook itself is the useful first result. Introduce Obsidian afterwards, if wanted.

## Legacy locations — read-only recovery evidence
`Setup/File-tool progress` and `Demonstration/Onboarding rehearsal/Setup/File-tool progress` were described by 0.2.1. Do not create new records there. The helper detects them and stops before starting another series. Its JSON checkpoints cannot automatically absorb those Markdown records.

No automatic route switching, import, overwrite, deletion or reset is provided. Even with approval, reconciliation is a separate reviewed task—not an implicit permission expansion during onboarding. [[Setup/Guided setup]] lists the currently supported locations and permission gates.

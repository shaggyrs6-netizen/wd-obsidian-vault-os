'use strict';

const TYPES = Object.freeze({
  capture: {folder:'Capture', template:'Capture', label:'capture'},
  project: {folder:'Projects', template:'Project', label:'project'},
  decision: {folder:'Projects/Decisions', template:'Decision', label:'decision', project:true},
  knowledge: {folder:'Knowledge', template:'Knowledge', label:'knowledge note'},
  topic: {folder:'Knowledge/Topics', template:'Topic', label:'topic guide'},
  source: {folder:'Sources', template:'Source', label:'source'},
  person: {folder:'People', template:'Person', label:'person'},
  conversation: {folder:'People/Conversations', template:'Conversation', label:'conversation'},
  everyday: {folder:'Everyday', template:'Everyday', label:'everyday note'},
  routine: {folder:'Everyday/Routines', template:'Routine', label:'routine'},
  writing: {folder:'Writing', template:'Writing', label:'writing note'},
  daily: {folder:'Journal/Daily', template:'Daily', label:"today's note", dated:true},
  weekly: {folder:'Journal/Reviews', template:'Weekly', label:'weekly review', dated:true},
  monthly: {folder:'Journal/Reviews', template:'Monthly', label:'monthly review', dated:true},
  handoff: {folder:'Continuity', template:'Handoff', label:'session handoff', project:true},
  verification: {folder:'System/Checks', template:'Verification', label:'verification record'}
});
const DEMO_PREFIX = 'Demonstration/';
function dateKey(now=new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
}
function weekKey(now=new Date()) {
  const d=new Date(now.getFullYear(),now.getMonth(),now.getDate(),12);
  d.setDate(d.getDate()-((d.getDay()+6)%7)); return dateKey(d);
}
function safeTitle(raw) {
  const title=String(raw || '').normalize('NFC').trim();
  if (!title || title.length>100 || /[\x00-\x1f\x7f<>:"/\\|?*\[\]#^{}]/u.test(title) || /[. ]$/.test(title) || title.startsWith('.') || /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(title)) {
    throw new Error('Use 1–100 characters without path separators, brackets or reserved filename characters.');
  }
  return title;
}
function meta(text,parseYaml) {
  const match=String(text).match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  if (!match) return {};
  try { const value=parseYaml(match[1]); return value && typeof value==='object' && !Array.isArray(value)?value:{}; } catch { return {}; }
}
function isUser(path,m) {
  return !path.startsWith(DEMO_PREFIX) && !path.startsWith('System/Templates/') && m.record_class==='user' && m.commitment_scope==='real' && !m.scenario_id;
}
function timestamp(m) {
  const s=m.recorded_at;
  if(typeof s!=='string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:\d\d)$/.test(s))return null;
  const y=Number(s.slice(0,4)),mo=Number(s.slice(5,7)),d=Number(s.slice(8,10));
  const calendar=new Date(Date.UTC(y,mo-1,d));
  if(calendar.getUTCFullYear()!==y||calendar.getUTCMonth()!==mo-1||calendar.getUTCDate()!==d||Number(s.slice(11,13))>23||Number(s.slice(14,16))>59||Number(s.slice(17,19))>59)return null;
  const value=Date.parse(s);return Number.isFinite(value)?value:null;
}
function chronology(records) {
  const handoffs=records.filter(r=>r.meta.kind==='handoff');
  const missing=handoffs.filter(r=>timestamp(r.meta)===null);
  const times=handoffs.map(r=>timestamp(r.meta)).filter(t=>t!==null);
  const tied=new Set(times).size!==times.length;
  return {uncertain:missing.length>0||tied,missing:missing.length,tied};
}
function compareRecords(a,b) {
  const at=timestamp(a.meta),bt=timestamp(b.meta);
  if(at!==null && bt!==null)return bt-at || a.path.localeCompare(b.path);
  if(at!==null)return -1;if(bt!==null)return 1;
  // Legacy dates are displayed, never interpreted as exact chronology.
  return String(b.meta.created||'').localeCompare(String(a.meta.created||'')) || a.path.localeCompare(b.path);
}
function isDemo(path,m) {
  return path.startsWith(DEMO_PREFIX) && m.record_class==='demonstration' && m.commitment_scope==='fictional' && typeof m.scenario_id==='string';
}
function select(records,filter={}) {
  const scope=filter.scope || 'user';
  if (!['user','demonstration'].includes(scope)) throw new Error('Unknown view scope.');
  if (filter.kind && !Object.hasOwn(TYPES,filter.kind)) throw new Error('Unknown record type.');
  return records.filter(r => (scope==='user'?isUser(r.path,r.meta):isDemo(r.path,r.meta))
    && (!filter.kind || r.meta.kind===filter.kind)
    && (!filter.project_id || r.meta.project_id===filter.project_id || (r.meta.kind==='project' && r.meta.record_id===filter.project_id)))
    .sort(compareRecords);
}
function plan(kind,input,template,context={}) {
  if(!Object.hasOwn(TYPES,kind)) throw new Error('Unknown creation action.'); const def=TYPES[kind];
  const now=context.now || new Date();
  const title=safeTitle(kind==='daily'?dateKey(now):kind==='weekly'?`Week of ${weekKey(now)}`:kind==='monthly'?`Month ${dateKey(now).slice(0,7)}`:input.title);
  const project=context.project;
  if(def.project && !project) throw new Error('Choose a real project first.');
  if(project && (!isUser(project.path,project.meta) || project.meta.kind!=='project' || typeof project.meta.record_id!=='string' || !project.meta.record_id)) throw new Error('The selected project is not a classified real project.');
  const id=context.id || globalThis.crypto.randomUUID();
  const path=`${def.folder}/${title}.md`;
  const values={title, input:String(input.input||'Not recorded yet.'), next:String(input.next||'Not decided yet.'), evidence:String(input.evidence||'Not checked.'), blocker:String(input.blocker||'None recorded.'), project_link:project?`[[${project.path.slice(0,-3)}|${project.meta.title || project.path.split('/').pop().slice(0,-3)}]]`:'No project selected.', date:kind==='weekly'?weekKey(now):dateKey(now), project_view:kind==='project'?`\n\`\`\`wd-view\n${JSON.stringify({scope:'user',project_id:id})}\n\`\`\`\n`:''};
  // Read the template as content, never code. Strip its classification and manual-only tail.
  let body=String(template).replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/,'').split('\n<!-- MANUAL-ONLY -->')[0];
  body=body.replace(/\{\{([a-z_]+)\}\}/g,(_,key)=>{if(!(key in values)) throw new Error(`Unknown template field: ${key}`);return values[key];});
  const front={record_class:'user',commitment_scope:'real',kind,record_id:id,title,created:dateKey(now),recorded_at:now.toISOString(),project_id:kind==='project'?id:(project?.meta.record_id||''),status:kind==='verification'?'unverified':kind==='writing'?'draft':'open'};
  const content=`---\n${Object.entries(front).map(([k,v])=>`${k}: ${JSON.stringify(v)}`).join('\n')}\n---\n${body.trim()}\n`;
  return {path,content,kind,projectPath:project?.path,projectOriginal:project?.content,templatePath:`System/Templates/${def.template}.md`,templateOriginal:template};
}
async function ensureParents(vault,path) {
  const parts=path.split('/');parts.pop();let current='';
  for(const part of parts) {
    current=current?`${current}/${part}`:part;
    if(!vault.getAbstractFileByPath(current)) await vault.createFolder(current);
  }
}
async function createChecked(vault,p) {
  // Only fixed product destinations are accepted, even if called outside the UI.
  const def=TYPES[p.kind];
  if(!Object.hasOwn(TYPES,p.kind) || !p.path.startsWith(`${def.folder}/`) || p.path.slice(def.folder.length+1).includes('/') || p.path!==`${def.folder}/${safeTitle(p.path.slice(def.folder.length+1,-3))}.md`) throw new Error('Invalid destination.');
  if(vault.getAbstractFileByPath(p.path)) throw new Error('A note already exists at this path. Nothing was replaced.');
  if((vault.getMarkdownFiles?.()||[]).some(f=>f.path.normalize('NFC').toLocaleLowerCase('en-US')===p.path.normalize('NFC').toLocaleLowerCase('en-US'))) throw new Error('A note with the same name and different capitalisation exists. Nothing was replaced.');
  if(p.projectPath) {
    const file=vault.getAbstractFileByPath(p.projectPath);
    if(!file || await vault.read(file)!==p.projectOriginal) throw new Error('The project changed after preview. Reopen the form and review the new context.');
  }
  const tf=vault.getAbstractFileByPath(p.templatePath);
  if(!tf || await vault.read(tf)!==p.templateOriginal) throw new Error('The template changed after preview. Reopen the form.');
  await ensureParents(vault,p.path);
  // Vault.create rejects an existing file. No modify/delete API is used here.
  const file=await vault.create(p.path,p.content);
  if(await vault.read(file)!==p.content) throw new Error('Read-back did not match. A file may exist; inspect it before retrying. Nothing was deleted.');
  return file;
}
module.exports={TYPES,dateKey,weekKey,safeTitle,meta,isUser,isDemo,select,plan,createChecked,timestamp,chronology,compareRecords};

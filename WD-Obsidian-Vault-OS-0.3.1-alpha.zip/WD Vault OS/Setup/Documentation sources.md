---
record_class: system
title: "Connection documentation checked"
---
# Connection documentation checked

Checked 13 October 2026. App interfaces and account availability can change. These are documentation checks, not successful local connection tests.

- [OpenAI: Projects and chats](https://learn.chatgpt.com/docs/projects) — local projects, Edit project/Add folder/Make primary, primary-folder context, and the distinction from uploaded ChatGPT project sources. Codex CLI can start in a chosen directory.
- [Anthropic: Cowork](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork) — desktop bridge for local access and current Chat/Cowork versus unified UI variation. Shell/cloud output and original-folder access differ.
- [Anthropic: one Claude](https://support.claude.com/en/articles/16761823-claude-cowork-and-chat-are-one-claude) — unified experience and local desktop dependence; connected folders are listed under Trusted folders.
- [Anthropic: desktop links](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link) — Cowork link with encoded folder and prompt, followed by folder confirmation.

The Claude pages differ in platform coverage. This package uses capability checks rather than claiming the same local experience works on every operating system. We did not change any account or test these links against a real account during authoring.

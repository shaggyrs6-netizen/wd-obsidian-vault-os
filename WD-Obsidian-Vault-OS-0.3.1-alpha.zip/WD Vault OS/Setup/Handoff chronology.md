---
record_class: system
title: "Handoff chronology"
---
# Handoff chronology

New WD Actions and helper records include `recorded_at` as an ISO timestamp with timezone. Exact timestamps sort by instant, newest first, even when filenames suggest a different order.

Legacy notes are not silently stamped with today's time or ordered by filesystem modification time. Missing, malformed or date-only timestamps remain uncertain. The UI puts exact timestamps first and labels older uncertain records with their recorded date, if any. That is display grouping, not proof that a timed note is newer than every legacy note.

When any relevant handoff lacks an exact time, or two have the same timestamp, the view warns that latest-state selection requires review. Alphabetical order only stabilises display ties. Read the project and compare decisions/evidence before declaring a latest handoff. A fresh assistant must not infer chronology from filename order.

Use project_id to select the relevant project first. Never choose the globally newest handoff for an unrelated project. Existing examples retain their relative scenario dates and are deliberately marked time-uncertain.

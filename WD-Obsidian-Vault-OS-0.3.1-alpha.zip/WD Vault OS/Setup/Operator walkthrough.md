---
record_class: system
title: "Lee\u2019s short fictional walkthrough"
---
# Lee’s short fictional walkthrough

1. Extract a fresh copy of 0.3.1. Open OPEN START.html and choose Claude or Codex. Tick **Use fictional test answers** before copying the prompt. Check that the page says **Mode: Fictional rehearsal**. Connect only the inner WD Vault OS folder.
2. Let the assistant check access read-only. If the local helper is available, it must ask permission for the full path ending in `Demonstration/Onboarding rehearsal/Progress`. Approve progress only. If not, choose user-saved manual rehearsal at `Demonstration/Onboarding rehearsal/Manual notes.md`; do not install anything to get past the check.
3. Answer Q1: **Arrange a small paper-star display.** Answer Q2: **Fold one sample star.** Then say: **“Pause now. Save my place and stop before question three.”** In manual mode, save the answers and resume point yourself. Reopen/read back before closing.
4. Start a fresh conversation with the same folder and the rehearsal resume prompt. It should retain both answers and continue at Q3. Say **not sure** to Q3; Q4: **One star stands without support.** Q5: **Open the sample sketch.** For Q6 choose **writing, daily, prism**; these are fictional choices, not installations or scheduled work.
5. Helper route: inspect the preview and four rehearsal paths, including the workflow menu. Only then say **“Yes, save these starter notes.”** Check the saved starting page. Repeat/resume once and confirm no duplicates. Manual route: the saved workbook is the result; do not count it as automatic four-note creation.
6. Only now open this separate folder in Obsidian and follow the result's links. Open [[AFTER SETUP|What to do after setup]] and [[RECENTS|Recent notes]]; check whether a saved note is clickable and its changed time appears. Note what you actually saw, including any failure. Keep the plugin disabled unless separately testing it.

Keep the complete real transcript if you consent, including capability/path disclosure, progress permission, all questions, pause, new-session pickup and final approval. Do not reconstruct missing turns. The app link itself remains untested until it actually connects the intended folder.

On separate disposable copies, an operator can additionally deny a write, edit an output or introduce older progress. The system should stop and preserve it. Do not alter account permissions or the live vault to simulate these cases.

Automated tests, mock-host tests, actual AI/app sessions, actual Obsidian use and beginner observation are different evidence classes. September's partial transcript is not a pass for this candidate.

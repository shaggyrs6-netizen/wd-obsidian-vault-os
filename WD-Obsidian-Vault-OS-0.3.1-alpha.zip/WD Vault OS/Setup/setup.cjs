'use strict';
// Optional deterministic local helper. No AI, account, network or Obsidian dependency.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const E=require('./record-engine.cjs');
const QUESTIONS=[
 'What is one thing you would like this vault to help you return to?',
 'What is one small next action you could take on it?',
 'How much capacity fits today: plenty, steady, a small step, or leave it for later?',
 'What could you see or check to know that small action was finished?',
 'If you stopped now, what tiny step should you restart with?',
 'Which extra help would you like now? Choose any: projects, readwise, daily, weekly, writing, prism; or say just basics.'
];
const WORKFLOWS={projects:['Projects/Keeping a project moving','Keep a project moving'],readwise:['Sources/Readwise and AI','Use Readwise with AI'],daily:['Journal/Daily and weekly notes','Try a factual daily note'],weekly:['Journal/Daily and weekly notes','Try a gentle weekly review'],writing:['Writing/From seed to article','Turn a seed into an article'],prism:['System/Prism appearance','Try the Prism look']};
function choices(raw){
 if(/^(skip|not sure|just basics|basic|none)$/i.test(raw.trim()))return [];
 const parts=raw.toLowerCase().split(/[,;]+/).map(x=>x.trim()).filter(Boolean);
 if(!parts.length||parts.some(x=>!Object.hasOwn(WORKFLOWS,x)))throw Error('Choose named options separated by commas, or say just basics.');
 return [...new Set(parts)];
}
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const parse=s=>Object.fromEntries(s.split('\n').filter(x=>x.includes(':')).map(x=>{const i=x.indexOf(':');let v=x.slice(i+1).trim();try{v=JSON.parse(v);}catch{}return[x.slice(0,i),v];}));
class Setup {
 constructor(root,{mode='real',now=()=>new Date()}={}){
  if(!['real','rehearsal'].includes(mode))throw Error('Unknown mode');
  this.root=fs.realpathSync(root);this.mode=mode;this.now=now;
  this.base=mode==='real'?'Setup/Progress':'Demonstration/Onboarding rehearsal/Progress';
  const identity=this.read('System/Package identity.md');if(!identity.includes('wd_package: wd-vault-os-complete'))throw Error('Wrong folder: package identity missing.');
  this.read('System/Templates/Project.md');this.read('System/Templates/Handoff.md');
 }
 resolve(rel){
  if(typeof rel!=='string'||rel.includes('\\')||path.isAbsolute(rel)||rel.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Unsafe relative path');
  let p=this.root;for(const part of rel.split('/')){p=path.join(p,part);if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Symlink refused');}
  return p;
 }
 read(rel){return fs.readFileSync(this.resolve(rel),'utf8');}
 exists(rel){return fs.existsSync(this.resolve(rel));}
 progressPath(){return this.resolve(this.base);}
 conflicts(){
  const locations=['Setup/Progress','Setup/File-tool progress','Demonstration/Onboarding rehearsal/Progress','Demonstration/Onboarding rehearsal/Setup/File-tool progress'];
  const found=locations.filter(p=>p!==this.base&&this.exists(p)&&(!fs.statSync(this.resolve(p)).isDirectory()||fs.readdirSync(this.resolve(p)).length));
  for(const p of ['MY FIRST NOTES.md','Demonstration/Onboarding rehearsal/Manual notes.md']){
   if(!this.exists(p))continue;
   const s=this.read(p);
   // Only the answer sections: shipped instructions/navigation are not progress.
   if([...s.matchAll(/^## (?:What I want to return to|My next small action|If I stop|Answer [1-5]|Optional help I want now|Next question and pause point)\r?\n([\s\S]*?)(?=^## |$(?![\s\S]))/gm)].some(m=>m[1].trim()))found.push(p);
  }
  return found;
 }
 checkPermission(s){
  if(s?.progress_permission?.path!==this.progressPath()||s?.progress_permission?.scope!=='interview-progress-only')throw Error('Progress permission is missing or for a different location. Stop and review; no automatic reconciliation.');
  const conflicts=this.conflicts();if(conflicts.length)throw Error('Other saved progress exists: '+conflicts.join(', ')+'. Stop for an explicitly approved reconciliation; nothing reset.');
 }
 put(rel,content){
  const p=this.resolve(rel);fs.mkdirSync(path.dirname(p),{recursive:true});this.resolve(rel);
  fs.writeFileSync(p,content,{flag:'wx',mode:0o600});
  const actual=this.read(rel);if(actual!==content)throw Error('Read-back mismatch: file preserved; stop and inspect.');return hash(actual);
 }
 load(){
  if(!this.exists(this.base))return null;
  const names=fs.readdirSync(this.resolve(this.base)).sort();
  if(names.some(x=>!/^\d{4}\.json$/.test(x)))throw Error('Unrecognised progress file; stop for review rather than starting another series.');
  let previous=null,raw='',seq=0;
  for(const name of names){
   if(Number(name.slice(0,4))!==seq+1)throw Error('Progress sequence has a gap. Stop for review.');
   const nextRaw=this.read(`${this.base}/${name}`);let s;try{s=JSON.parse(nextRaw);}catch{throw Error('Incomplete progress checkpoint; stop for review.');}
   if(s.seq!==++seq || s.prev!==(previous?hash(raw):null) || s.mode!==this.mode || s.version!==1)throw Error('Progress integrity check failed.');
   previous=s;raw=nextRaw;
  }
  return previous;
 }
 save(s,event){
  this.checkPermission(s);
  const old=this.load();if((old?.seq||0)!==(s.seq||0))throw Error('Progress changed in another session. Reload.');
  const seq=(old?.seq||0)+1;if(seq>9999)throw Error('Checkpoint limit reached.');
  const prev=old?hash(this.read(`${this.base}/${String(old.seq).padStart(4,'0')}.json`)):null;
  const next={...s,version:1,mode:this.mode,seq,prev,recorded_at:this.now().toISOString(),event};
  this.put(`${this.base}/${String(seq).padStart(4,'0')}.json`,JSON.stringify(next,null,2)+'\n');return next;
 }
 status(){
  const s=this.load();return {root:this.root,mode:this.mode,progress_location:this.progressPath(),other_saved_progress:this.conflicts(),permission_valid:s?.progress_permission?.path===this.progressPath()&&s?.progress_permission?.scope==='interview-progress-only',state:s,next_question:s?s.answers.findIndex(a=>a.status==='pending')+1:1,questions:QUESTIONS};
 }
 start(approvedPath){
  const s=this.load();if(s){this.checkPermission(s);return this.status();}
  if(approvedPath!==this.progressPath())throw Error('Before the first write, explain and obtain permission for this exact progress location: '+this.progressPath()+'. Starter notes need separate approval.');
  const permission={path:approvedPath,scope:'interview-progress-only'};this.checkPermission({progress_permission:permission});
  const baseline={};for(const p of ['System/Package identity.md','System/Templates/Project.md','System/Templates/Handoff.md','System/Workflow choices.md'])baseline[p]=hash(this.read(p));
  this.save({seq:0,answers:QUESTIONS.map(()=>({status:'pending',text:''})),status:'interviewing',baseline,session_id:crypto.randomUUID(),root_checked:this.root,progress_permission:permission},'permitted-local-progress-readback');return this.status();
 }
 answer(index,text){
  let s=this.load();if(!s)throw Error('Start first.');if(!['interviewing','paused'].includes(s.status))throw Error('Answers are frozen for the current preview. Start no replacement silently.');
  const expected=s.answers.findIndex(a=>a.status==='pending');if(expected<0||index<1||index>QUESTIONS.length||index!==expected+1)throw Error('Only the next unanswered question can be recorded.');
  if(typeof text!=='string'||!text.trim()||text.length>4000)throw Error('Answer must be 1–4000 characters.');
  if(index===QUESTIONS.length)choices(text);
  const skip=/^(skip|not sure)$/i.test(text.trim());
  s.answers[index-1]={status:skip?'skipped':'answered',text:skip?(index===QUESTIONS.length?'just basics':'Not decided yet.'):text.trim()};
  s.status='interviewing';this.save(s,`answer-${index}-readback`);return this.status();
 }
 pause(){const s=this.load();if(!s)throw Error('Start first.');if(s.status==='interviewing')s.status='paused';this.save(s,'user-requested-pause');return this.status();}
 makePlans(s){
  for(const [p,h] of Object.entries(s.baseline))if(hash(this.read(p))!==h)throw Error('Package template changed during setup. Review before proceeding.');
  const a=s.answers.map(x=>x.text),now=this.now();
  const project=E.plan('project',{title:'My first project',input:a[0],next:a[1],evidence:'Finish criterion (not completed): '+a[3]},this.read('System/Templates/Project.md'),{id:s.session_id,now});
  project.content=project.content.replace('Capacity: not chosen.','Capacity: '+a[2].replace(/[\r\n]+/g,' ') + '.');
  if(this.mode==='rehearsal')this.asDemo(project,'Demonstration/Onboarding rehearsal/Projects/My first project.md');
  // The generic engine rejects demo projects by design. Link only after rendering in rehearsal.
  const realContext={path:'Projects/My first project.md',content:project.content,meta:{record_class:'user',commitment_scope:'real',kind:'project',record_id:s.session_id,title:'My first project'}};
  const handoff=E.plan('handoff',{title:'First setup handoff',input:'Starter notes approved; underlying work is not completed.',next:a[4],evidence:'At setup, starter files will be read back. Obsidian display is a separate check.'},this.read('System/Templates/Handoff.md'),{project:realContext,id:s.session_id+'-handoff',now});
  if(this.mode==='rehearsal'){
   this.asDemo(handoff,'Demonstration/Onboarding rehearsal/Continuity/First setup handoff.md');
   handoff.content=handoff.content.replaceAll('[[Projects/My first project|','[[Demonstration/Onboarding rehearsal/Projects/My first project|');
   project.content=project.content.replace('"scope":"user"','"scope":"demonstration"');
  }
  const selected=choices(a[5]);
  const workflowPath=this.mode==='real'?'MY WORKFLOWS.md':'Demonstration/Onboarding rehearsal/MY WORKFLOWS.md';
  const workflowLinks=selected.map(x=>`- [[${WORKFLOWS[x][0]}|${WORKFLOWS[x][1]}]]`).join('\n');
  const workflows={path:workflowPath,content:`---\nrecord_class: ${this.mode==='real'?'user':'demonstration'}\ncommitment_scope: ${this.mode==='real'?'real':'fictional'}\nkind: workflow-choices\n${this.mode==='rehearsal'?'scenario_id: onboarding-rehearsal\n':''}record_id: ${JSON.stringify(s.session_id+'-workflows')}\nrecorded_at: ${JSON.stringify(now.toISOString())}\n---\n# My workflows\n\n${this.mode==='rehearsal'?'> FICTIONAL REHEARSAL — these choices are not real commitments.\n\n':''}The project and handoff are your starting place. You chose: ${selected.length?selected.join(', '):'just basics'}. This is a menu, not an automatic installation or schedule.\n\n${workflowLinks||'No extra workflow chosen yet. Start with your project and handoff; other guides remain on Home.'}\n\nYou can change these choices later. Ask an assistant to propose a scoped edit and show it before saving, or edit this note yourself.\n\n[[${this.mode==='real'?'MY STARTING POINT':'Demonstration/Onboarding rehearsal/MY STARTING POINT'}|My starting point]] · [[HOME|Home]]\n`};
  const landing={path:this.mode==='real'?'MY STARTING POINT.md':'Demonstration/Onboarding rehearsal/MY STARTING POINT.md',content:`---\nrecord_class: ${this.mode==='real'?'user':'demonstration'}\ncommitment_scope: ${this.mode==='real'?'real':'fictional'}\nkind: starting-point\nrecord_id: ${JSON.stringify(s.session_id+'-start')}\nproject_id: ${JSON.stringify(s.session_id)}\n${this.mode==='rehearsal'?'scenario_id: onboarding-rehearsal\n':''}recorded_at: ${JSON.stringify(now.toISOString())}\n---\n# My starting point\n\n${this.mode==='rehearsal'?'> FICTIONAL REHEARSAL — not real commitments.\n\n':'> YOUR NOTES — these answers were saved as your own work.\n\n'}## One thing to return to\n${a[0]}\n\n## Next small action\n${a[1]}\n\n## If I stop\n${a[4]}\n\n[[${project.path.slice(0,-3)}|My project]] · [[${handoff.path.slice(0,-3)}|My handoff]]\n\nThe setup helper checked these saved files. It could not check what Obsidian displayed.\n\n## What next?\n[[${workflowPath.slice(0,-3)}|My chosen workflows]] · [[AFTER SETUP|Choose what to do next]] · [[RECENTS|Find a note you just made]]\n\n[[HOME|Home]] · [[START HERE|Starting choices]]\n`};
  return [project,handoff,landing,workflows].map(({path,content})=>({path,content,sha256:hash(content)}));
 }
 asDemo(p,newPath){p.path=newPath;p.content=p.content.replace('record_class: "user"','record_class: "demonstration"\nscenario_id: "onboarding-rehearsal"').replace('commitment_scope: "real"','commitment_scope: "fictional"').replace(/\n# /,'\n> FICTIONAL REHEARSAL — not real commitments.\n\n# ');}
 preview(){
  let s=this.load();if(!s||s.answers.some(a=>a.status==='pending'))throw Error('Complete or skip all six questions first.');
  if(s.plans)return s;
  s.plans=this.makePlans(s);s.status='awaiting-confirmation';s.approval=null;return this.save(s,'preview-ready-not-approved');
 }
 confirm(text){
  let s=this.load();if(!s||s.status!=='awaiting-confirmation')throw Error('Show the preview first.');
  if(text!=='Yes, save these starter notes.')throw Error('Explicit preview approval is required.');
  s.approval={text,recorded_at:this.now().toISOString(),plan_hash:hash(JSON.stringify(s.plans))};s.status='confirmed';return this.save(s,'explicit-confirmation-recorded');
 }
 create(){
  let s=this.load();if(!s?.approval||!['confirmed','saved'].includes(s.status)||s.approval.plan_hash!==hash(JSON.stringify(s.plans)))throw Error('No valid approval for these exact notes.');
  this.checkPermission(s);
  for(const [p,h] of Object.entries(s.baseline))if(hash(this.read(p))!==h)throw Error('Package changed since preview. Stop for review.');
  // Check every destination before creating any output, including case-only collisions.
  for(const p of s.plans){
   if(hash(p.content)!==p.sha256)throw Error('Plan integrity failed.');
   if(this.exists(p.path)&&this.read(p.path)!==p.content)throw Error(`Existing or user-edited note preserved: ${p.path}`);
   const parent=path.posix.dirname(p.path);
   if((parent==='.'||this.exists(parent))&&fs.readdirSync(parent==='.'?this.root:this.resolve(parent)).some(n=>n.toLowerCase()===path.posix.basename(p.path).toLowerCase()&&n!==path.posix.basename(p.path)))throw Error('Case-only destination collision.');
  }
  const checks=[];
  for(const p of s.plans){const reused=this.exists(p.path);if(!reused)this.put(p.path,p.content);if(this.read(p.path)!==p.content)throw Error('Output read-back failed.');checks.push({path:p.path,sha256:hash(this.read(p.path)),reused});}
  if(s.status!=='saved'){s.status='saved';s.outputs=checks;this.save(s,'all-output-readbacks-passed');}
  return {status:'saved',root:this.root,checks,obsidian:'not verified'};
 }
}
module.exports={Setup,QUESTIONS,hash};
if(require.main===module){
 try{
  // The helper's location binds the selected vault; a cloud copy only binds that copy.
  const args=process.argv.slice(2),mode=args.includes('--rehearsal')?'rehearsal':'real';
  const filtered=args.filter(x=>x!=='--rehearsal'),op=filtered[0]||'status';
  const setup=new Setup(path.resolve(__dirname,'..'),{mode});let r;
  if(op==='start'){if(filtered[1]!=='--allow-progress')throw Error('Use status first. start requires --allow-progress and the exact user-approved absolute progress path.');r=setup.start(filtered[2]);}else if(op==='status')r=setup.status();else if(op==='answer')r=setup.answer(Number(filtered[1]),filtered.slice(2).join(' '));else if(op==='pause')r=setup.pause();else if(op==='preview')r=setup.preview();else if(op==='confirm')r=setup.confirm(filtered.slice(1).join(' '));else if(op==='create')r=setup.create();else throw Error('Unknown operation');
  console.log(JSON.stringify(r,null,2));
 }catch(e){console.error(e.message);process.exitCode=1;}
}

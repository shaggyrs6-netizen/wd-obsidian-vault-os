---
record_class: "system"
title: "Decision desk"
---
# Decision desk

Keep the choice, why it was made and what would change it. Supersede old decisions explicitly rather than erasing the history.


```wd-action
{"action": "decision", "label": "New decision"}
```

```wd-view
{"scope": "user", "kind": "decision"}
```

## Without the plugin
Create a note in `Projects/Decisions/` and insert [[System/Templates/Decision|the decision template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Group by growing conditions]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

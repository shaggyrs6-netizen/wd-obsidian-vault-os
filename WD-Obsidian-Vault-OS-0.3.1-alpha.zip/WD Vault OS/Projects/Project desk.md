---
record_class: "system"
title: "Project desk"
---
# Project desk

Each project has its own outcome, evidence, blocker and restart point. Capacity belongs to today; project status describes the work.


```wd-action
{"action": "project", "label": "New project"}
```

```wd-view
{"scope": "user", "kind": "project"}
```

## Without the plugin
Create a note in `Projects/` and insert [[System/Templates/Project|the project template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Seed library pilot]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

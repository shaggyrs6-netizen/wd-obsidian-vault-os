---
record_class: system
title: "Keeping a project moving"
---
# Keeping a project moving

One project note should answer: **What is this? Where is it now? What is one next action?** Link a dated handoff when you stop. The handoff records the last checked state, any uncertainty, and the smallest restart step. A project is not finished because an assistant wrote a neat summary.

Ask your connected assistant:

> Read my starting point, this project and its latest linked handoff. Tell me the current state, what you can verify, and one next action. Do not change notes yet.

When you make progress, ask it to **propose** a short update. Check the proposed facts and exact file before approving a write. If it cannot read the original vault folder, use [[System/Manual creation|manual creation]] instead. [[RECENTS|Recent notes]] finds a note later.

[[Projects/Project desk|Projects]] · [[Continuity/Continuity desk|Handoffs]] · [[RETURN|Return]]

---
record_class: "system"
title: "The furnished example"
---
# The furnished example

> [!example] Entirely fictional
> This tour contains invented people, sources, projects and tasks. They are teaching material, not your life or commitments. No sample date creates a real deadline.

## Two projects, two independent contexts
| Project | Owner in the story | Current blocker | Start |
|---|---|---|---|
| Seed library pilot | Rowan Vale | Shelf dimensions not confirmed | [[Demonstration/Seed/Seed library pilot]] |
| Harbour sound map | Ellis Fen | Rehearsal recording permission not confirmed | [[Demonstration/Sound/Harbour sound map]] |

They share a demonstration journal, but neither project borrows the other's people, decisions, sources or next action. [[Demonstration/Switch projects]] makes the difference explicit.

## A useful tour
1. [[Demonstration/Seed/An unused shelf|Capture a thought]].
2. [[Demonstration/Seed/Seed library pilot|See a project with progress and a blocker]].
3. [[Demonstration/Seed/Trial observations|Follow a source]] into [[Demonstration/Seed/Organise around the first question|a knowledge note]].
4. [[Demonstration/Seed/Alphabetical seemed obvious|See an earlier opinion]] and [[Demonstration/Seed/Group by growing conditions|the later decision]].
5. [[Demonstration/Seed/Newsletter draft|Read the resulting writing]].
6. [[Demonstration/Sound/Pause after the clipping test|Switch to an interrupted independent task]].
7. [[Demonstration/Journal/Week 01 - What changed|See the weekly review]].
8. [[Demonstration/Journal/Day 10 - Returning after a gap|Return after several missing days]], then read [[Demonstration/Journal/Month 01 - Keep the useful parts|a bounded longer review]].

## Start your own work alongside this
Use HOME's creation actions or [[System/Manual creation]]. They use clean templates and save outside Demonstration. Do not edit an example into a real task by changing its name. [[System/Remove demonstrations]] explains a reviewed, recoverable removal later.

---
record_class: "system"
title: "Check desk"
---
# Check desk

Record the actual check, outcome and limits. A convincing answer is not evidence.


```wd-action
{"action": "verification", "label": "New verification"}
```

```wd-view
{"scope": "user", "kind": "verification"}
```

## Without the plugin
Create a note in `System/Checks/` and insert [[System/Templates/Verification|the verification template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Sound/Clipping check result]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

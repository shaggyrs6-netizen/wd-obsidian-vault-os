---
record_class: "system"
title: "AI connections"
---
# AI connections

## Choose one route initially

| Route | Context received | User setup | Without it |
|---|---|---|---|
| File-capable desktop or CLI assistant | Only the folder and files its tools actually permit | Own account/runtime; select this vault; set permissions; explicitly read AI/START | Manual editing works |
| Browser chat | Text you deliberately paste or attach | Own account; supply a small context packet; save results yourself | No assistant needed |
| Local model through an agent | Context and tools supplied by the local agent | Own local runtime/model; tool and write tests | Manual editing works |
| Cloud document connector | Selected cloud documents, not automatic local-vault access | Own vendor connection and consent; deliberate export scope | Keep context local |

Vendor-managed connectors are different from user-created OAuth clients. Do not ask a beginner to create a client unless a chosen integration actually requires it. Never ship client secrets or assume authentication in one app applies to another.

## Demonstrate capability before relying on it
Identify the root and permitted files. A read test does not prove write access. If you authorise a harmless new note, save and read it back at the exact path. A downloadable cloud artifact is not a local save. Recheck after reconnecting or changing app.

Use [[AI/START]] and [[AI/Permission policy]]. Hosted assistants process supplied content through their service; local-first storage is not a promise of local-only inference. Supply the smallest relevant context.

## Optional integrations
Readwise: own account and importer; bring sources into Sources, then review them. Calendar/contacts: own account and permissions; keep local records usable without sync. Publishing: explicit destination and final approval every time. Backup: choose and test a destination. None is connected, installed or scheduled by this package.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "Navigation and links"
---
# Navigation and links

HOME is the front door; section desks are the room entrances; a project is the centre of its own context. RETURN helps choose a project, not a universal last conversation.

Use ordinary wikilinks between notes. Backlinks show where a note is used. A source can support several ideas; an idea can support several projects. Reuse the knowledge, not a project's permission or next action.

The graph and search are additional views. No custom query language is required to follow the static links. Plugin lists filter classified records, so incomplete manually created metadata may hide a note from those lists while it remains searchable in the file explorer.

When renaming, inspect backlinks and unresolved references afterwards. When deleting or moving, make a reviewed plan and a backup first. Hubs should be repaired before removing their targets.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

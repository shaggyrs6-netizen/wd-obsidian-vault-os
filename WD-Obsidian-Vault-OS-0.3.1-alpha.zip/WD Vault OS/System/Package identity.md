---
record_class: "system"
title: "Package identity"
---
# Package identity

wd_package: wd-vault-os-complete

Alpha test version 0.3.1. Original WD Actions code and fictional examples remain. This version adds optional workflow choices, guides and templates, plus bundled Prism appearance. This marker prevents accidental plugin loading in an unrelated vault; it is not a permission grant or security boundary.

The separate engineering folder contains BUILD-SPEC.md, provenance, tests and acceptance results. Do not confuse a packaged file with a validated live workflow.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

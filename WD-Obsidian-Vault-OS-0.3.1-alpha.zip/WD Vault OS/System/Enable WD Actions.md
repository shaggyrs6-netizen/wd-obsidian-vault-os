---
record_class: "system"
title: "Enable WD Actions"
---
# Enable WD Actions

WD Actions is original local code included in `.obsidian/plugins/wd-actions/`. No plugin download or account is required. It is not marketplace-published or independently audited.

1. Confirm you opened this separate WD Vault OS folder, not an existing personal vault.
2. Open Obsidian Settings → Community plugins. Decide whether to allow community plugins in this vault.
3. Enable **WD Actions** from the installed list.
4. Open HOME in Reading view. Try Capture a thought, preview the target and create one harmless test note.
5. Confirm the saved content in the note. Delete nothing automatically; you may keep the test as your first capture.

The same actions are in the command palette under WD Actions. If buttons do not render, use Reading view or the command palette. If the plugin fails, disable it and use [[System/Manual creation]]. Your Markdown remains intact.

The plugin uses Obsidian's Vault API, does not call network or shell services and refuses to load without this package's identity note. This is a guard against an accidental install, not a security sandbox. Do not place symlinks into the vault or treat unreviewed plugins as confined by Markdown policies.

Desktop target: Obsidian 1.13.7. Earlier versions and mobile require separate validation. No setting in your other vaults should be changed.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

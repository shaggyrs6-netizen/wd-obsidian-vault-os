---
record_class: "system"
title: "Connection status"
---
# Connection status

This is a manual register. An available tool does not prove a working connection.

| Connection | State | Scope | Last checked | Fallback |
|---|---|---|---|---|
| AI file access | Not configured | None | Not tested | Manual editing |
| Source importer | Not configured | None | Not tested | New source note |
| Calendar / contacts | Not configured | None | Not tested | Everyday / People notes |
| Publishing | Not configured | None | Not tested | Local drafts |
| Backup | Not configured | None | Not tested | Choose destination and test restore |

Add no tokens here. Record failures explicitly. A service outage must not turn a local task into a claimed send or successful sync.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: template
commitment_scope: none
kind: handoff
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Project
{{project_link}}

## Last confirmed state
{{input}}

## First restart action
{{next}}

## Blocker
{{blocker}}

## What was checked
{{evidence}}

## Files and decisions to read
Start with the linked project, then add only the records needed for this task.

## Permission boundary
Reading this record grants no new permission. No external communication, publication, deletion or policy change is authorised by it.
[[Continuity/Continuity desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

---
record_class: template
commitment_scope: none
kind: knowledge
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## The idea
{{input}}

## What supports it
{{evidence}}

## Limits and counterexamples
Not assessed yet. A clear sentence is not necessarily a true one.

## Where it helps
{{project_link}}

## Open question
{{next}}

## Changed position
No earlier view linked. Preserve it if this note revises one.
[[Knowledge/Knowledge desk]] · [[Sources/Source desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

---
record_class: template
commitment_scope: none
kind: routine
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## When this is useful
{{input}}

## Short checklist
- [ ] Confirm the routine applies today.
- [ ] {{next}}
- [ ] Leave a brief note about anything that changed.

## Stop or adapt when
{{blocker}}

## Last real test
{{evidence}}
This is a reusable checklist, not a scheduled task. Copy it into a dated note before checking it off for a particular occasion.
[[Everyday/Routines/Routine desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

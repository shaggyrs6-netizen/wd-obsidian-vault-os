---
record_class: template
commitment_scope: none
kind: article-draft
status: draft
---
# {{Working title}}

Source seed: {{link to seed}}  
Project: {{link if relevant}}  
Reader: {{who this is for}}  
Main point: {{one sentence}}  
Stage: local draft

## Draft
{{Write from the person's actual material. Keep sources and inferences distinguishable.}}

## Claims to check
- {{Claim — source or “unverified”}}

## Optional publication metadata — review before use
- Subtitle: {{optional}}
- SEO headline: {{optional}}
- SEO title: {{optional}}
- SEO description: {{optional}}
- URL slug: {{optional}}
- Tags: {{optional, few and specific}}
- Image prompt: {{subject, composition, mood, format, exclusions; no personal facts invented}}

## Review and next step
{{What needs Lee's or the writer's judgement? One small action.}}

Local draft only. No external draft, image, schedule or publication is implied. Copy this template into a new `Writing/` note; leave the original unchanged.

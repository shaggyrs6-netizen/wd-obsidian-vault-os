---
record_class: template
commitment_scope: none
kind: topic
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## What this guide helps you find
{{input}}

## Start with these ideas
Add a few links to existing notes, with one sentence explaining each.

## Questions and disagreements
{{next}}

## Sources worth returning to
{{evidence}}

## Work using this topic
{{project_link}}
[[Knowledge/Topics/Topic desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

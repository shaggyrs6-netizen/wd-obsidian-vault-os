---
record_class: template
commitment_scope: none
kind: weekly
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Period actually covered
Week beginning {{date}}; confirm the end date and which days have records. Unrecorded days are unknown.

## What mattered
{{input}}

## Evidence from daily and project notes
{{evidence}}

## Carry forward
{{next}}

## Park or stop
No choice made yet. Do not turn every idea into a task.

## Still uncertain
{{blocker}}

## Related project
{{project_link}}
[[Journal/Reviews/Review desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

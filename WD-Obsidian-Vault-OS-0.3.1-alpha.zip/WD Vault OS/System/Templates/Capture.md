---
record_class: template
commitment_scope: none
kind: capture
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Captured thought
{{input}}

## Where it might belong
{{project_link}}

## Next small action
{{next}}

Keep it here until you know whether it is work, a question, a source or something to leave alone.
[[Capture/Capture desk|Back to capture]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

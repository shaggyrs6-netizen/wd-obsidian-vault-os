---
record_class: template
commitment_scope: none
kind: project
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Outcome
{{input}}

## Current position
State: open. Capacity: not chosen. A quiet project and low capacity are different things.

## Next small action
{{next}}

## Blocker
{{blocker}}

## Evidence of progress
{{evidence}}

## Decisions and changed views
No decision recorded yet. Link a decision when there is one; preserve superseded decisions with a forward link.

## Related records
{{project_view}}
The view uses this project's stable ID. Without the plugin, add links here as you create sources, decisions, writing and handoffs.
[[Projects/Project desk|Project desk]] · [[Continuity/Continuity desk|Leave a handoff]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

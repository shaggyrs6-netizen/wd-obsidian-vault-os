---
record_class: template
commitment_scope: none
kind: source
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Source identity and access
{{input}}

Record author, title, date, URL or local attachment and the date accessed when known. Unknown values stay unknown. Do not paste credentials or entire copyrighted works.

## What it actually says
Distinguish a short quotation from your paraphrase. Keep attribution.

## Why I kept it
{{next}}

## Reliability and limits
{{evidence}}

## Used by
{{project_link}}
Link knowledge or writing produced from this source; an import alone is not synthesis.
[[Sources/Source desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

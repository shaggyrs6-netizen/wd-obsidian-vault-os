---
record_class: template
commitment_scope: none
kind: decision
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Decision
{{input}}

## Project
{{project_link}}

## Why this choice
Record the alternatives and the evidence that mattered. Do not invent consensus.

## What would make us revisit it
{{blocker}}

## Next action
{{next}}

## Checked evidence
{{evidence}}

## Earlier or later decision
None linked yet. If replacing a view, link in both directions and mark the old one superseded.
[[Projects/Decisions/Decision desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

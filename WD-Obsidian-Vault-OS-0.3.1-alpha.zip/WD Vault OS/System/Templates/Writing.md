---
record_class: template
commitment_scope: none
kind: writing
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Brief
{{input}}

Audience and intended use: not chosen yet.

## Supporting ideas and sources
{{project_link}}
{{evidence}}

## Outline or draft
Write here when ready. Keep sourced claims distinguishable from your interpretation.

## Next writing action
{{next}}

## Review and unresolved claims
{{blocker}}

## Delivery state
Local draft only. No external draft, schedule or publication has been created. Record a destination and separate evidence if that later changes.
[[Writing/Writing desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

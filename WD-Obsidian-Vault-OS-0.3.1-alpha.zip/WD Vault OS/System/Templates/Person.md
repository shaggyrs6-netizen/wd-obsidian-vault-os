---
record_class: template
commitment_scope: none
kind: person
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## Useful context
{{input}}

Keep only context needed for the relationship. Contact details are optional, not required fields.

## Conversations
Link a conversation record when one exists.

## Follow-up I chose
{{next}}

## Permission and sensitivity
No external contact authorised by this note. Avoid private detail that does not help.
[[People/People desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

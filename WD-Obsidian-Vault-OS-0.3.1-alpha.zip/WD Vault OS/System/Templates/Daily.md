---
record_class: template
commitment_scope: none
kind: daily
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## One useful focus
{{input}}

## What actually happened
Nothing recorded yet. Append events as they happen; do not fill a quiet day with guesses.

## Next small action
{{next}}

## Uncertainty or blocker
{{blocker}}

## Evidence and related work
{{evidence}}
{{project_link}}

## Coverage
Started {{date}}. This note is not a claim that the whole day has been reviewed.
[[Journal/Journal desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

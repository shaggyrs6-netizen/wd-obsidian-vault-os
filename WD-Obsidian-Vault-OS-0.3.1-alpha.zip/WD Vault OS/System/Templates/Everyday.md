---
record_class: template
commitment_scope: none
kind: everyday
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## What needs remembering
{{input}}

## Small next action
{{next}}

## What is blocked
{{blocker}}

## Useful reference
{{evidence}}

## Related work, if any
{{project_link}}
Not every errand needs to become a project. No reminder or calendar event is created by this note.
[[Everyday/Everyday desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

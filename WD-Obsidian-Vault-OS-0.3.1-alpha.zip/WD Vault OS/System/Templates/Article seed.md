---
record_class: template
commitment_scope: none
kind: article-seed
status: idea
---
# {{Working title}}

## The spark
{{One observation, question or scene in your own words. A fragment is enough.}}

## Why it matters to me
{{Optional. Leave blank if you do not know yet.}}

## Possible reader and point
Reader: not chosen yet.  
Main point: not chosen yet.

## Evidence and links
{{Links to relevant project, handoff and sources. Mark unverified claims.}}

## Small next step
{{One small step, or “leave it here”.}}

This is a local seed. No article draft or publication is implied. Copy this template into a new `Writing/` note; leave the original unchanged.

---
record_class: template
commitment_scope: none
kind: conversation
record_id: ""
project_id: ""
created: ""
status: open
---
# {{title}}

## What was discussed
{{input}}

## People
Link the relevant person records. Separate what someone said from your interpretation.

## Related work
{{project_link}}

## Explicit agreement or follow-up
{{next}}

## Uncertain or blocked
{{blocker}}

## Evidence
{{evidence}}
This note does not authorise sending messages or creating calendar events.
[[People/Conversations/Conversation desk]]

<!-- MANUAL-ONLY -->
## Manual completion — remove this section from your new note
This is a template. After inserting it into a new note, set `record_class: user`, `commitment_scope: real`, a unique `record_id`, `title` and `created`. Replace the brace fields with your own text. For a project set `project_id` equal to its record ID; for a linked record use the selected project's ID. Remove the `project_view` field if working manually and add links instead. Do not change the original template. See [[System/Manual creation]].

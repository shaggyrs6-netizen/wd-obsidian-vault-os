---
record_class: system
title: "Third-party credits"
---
# Third-party credits

Prism theme 3.8.0 by Damian Korcz: https://github.com/damiankorcz/Prism-Theme . MIT license included at `.obsidian/themes/Prism/LICENSE`. Theme CSS and manifest were copied from the selected local Prism installation for this alpha build; no personal style settings or other vault files were copied. Prism documents embedded Source Sans and JetBrains Mono fonts under SIL Open Font License 1.1. Their copyright notices and licences are included at `.obsidian/themes/Prism/SOURCE-SANS-LICENSE.md` and `.obsidian/themes/Prism/JETBRAINS-MONO-OFL.txt`.

Readwise Official is **not bundled**. The guide links to Readwise's own instructions. No Readwise data or account information is included.

[[System/Prism appearance|Prism appearance]] · [[HOME|Home]]

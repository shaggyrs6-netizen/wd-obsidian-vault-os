---
record_class: "system"
title: "My setup"
---
# My setup

This record is yours to edit manually; nothing here runs an installer.

| Choice | Current value |
|---|---|
| Vault opened correctly | Not checked |
| Navigation mode | Manual; interactive optional |
| WD Actions enabled | Not checked |
| First real note saved | Not checked |
| AI route and folder scope | Not chosen |
| Session recording permission | Not granted by default |
| Backup destination and last restore test | Not chosen / not tested |
| Optional workflow choices | See the saved starting point after guided setup; otherwise not chosen |
| Readwise account and sync | Not connected by setup |
| Daily / weekly note updates | Off until separately requested |
| Prism appearance | Bundled, not selected by setup |

Record only the choices you actually made. An unanswered choice does not block ordinary note use. [[System/AI connections]] explains the optional connection routes.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

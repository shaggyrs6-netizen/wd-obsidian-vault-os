---
record_class: system
title: "Choose the help you want"
---
# Choose the help you want

The first project and handoff work for everyone. After those five short questions, setup asks one optional question: **what else would help you now?** Choose any, or say **just basics**. Nothing is installed or connected by this choice.

| Choice | What it adds to your starting page |
|---|---|
| `projects` | A simple project status and handoff routine |
| `readwise` | How to import highlights and decide what is worth keeping |
| `daily` | An optional, factual daily note |
| `weekly` | An optional, gentle weekly review |
| `writing` | A seed → outline → article route with metadata and image brief |
| `prism` | How to turn on the bundled Prism theme, if you like it |

You can choose several, for example `writing, daily, prism`. **Skip**, **not sure**, and **just basics** all leave the extra choices off for now. Every guide remains available from [[HOME|Home]], and you can change your own `MY WORKFLOWS.md` later. The assistant must ask before writing your choice or creating notes.

[[HOME|Home]] · [[AFTER SETUP|After setup]]

---
record_class: "system"
title: "Backup and recovery"
---
# Backup and recovery

## Before relying on this system
Choose a backup destination separately from the working folder. A synced folder is not by itself proof that deleted or overwritten files can be recovered.

## Manual full-copy route
Close editing activity. Copy the entire vault folder, including `.obsidian` and attachments, to a separately chosen location. Keep that copy private. Record the date and whether hidden files were included. No copy tool or schedule runs automatically in this package.

## Verify recovery
Restore a copy into a new folder, never on top of the current vault. Open that restored folder only when ready. Check a project, its handoff, a source, an attachment and the navigation. Compare file counts and checksums using tools you trust. Record the actual results in a Verification note.

## Version history
Git can optionally preserve selected files. Excluded files and uncommitted edits require separate coverage. Remote storage is an external disclosure and needs deliberate account, privacy and credential decisions.

## Failed integration
Keep local notes. Record what failed and the last known success. Use the manual route while the service is unavailable; do not silently retry a send or publication.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "Template catalogue"
---
# Template catalogue

| Type | Destination | Template |
|---|---|---|
| capture | `Capture/` | [[System/Templates/Capture]] |
| project | `Projects/` | [[System/Templates/Project]] |
| decision | `Projects/Decisions/` | [[System/Templates/Decision]] |
| knowledge | `Knowledge/` | [[System/Templates/Knowledge]] |
| topic | `Knowledge/Topics/` | [[System/Templates/Topic]] |
| source | `Sources/` | [[System/Templates/Source]] |
| person | `People/` | [[System/Templates/Person]] |
| conversation | `People/Conversations/` | [[System/Templates/Conversation]] |
| everyday | `Everyday/` | [[System/Templates/Everyday]] |
| routine | `Everyday/Routines/` | [[System/Templates/Routine]] |
| writing | `Writing/` | [[System/Templates/Writing]] |
| article seed (manual or assistant) | `Writing/` | [[System/Templates/Article seed]] |
| article draft (manual or assistant) | `Writing/` | [[System/Templates/Article draft]] |
| daily | `Journal/Daily/` | [[System/Templates/Daily]] |
| weekly | `Journal/Reviews/` | [[System/Templates/Weekly]] |
| monthly | `Journal/Reviews/` | [[System/Templates/Monthly]] |
| handoff | `Continuity/` | [[System/Templates/Handoff]] |
| verification | `System/Checks/` | [[System/Templates/Verification]] |

WD Actions buttons use the original type templates; the article seed and draft templates are for manual or reviewed assistant use. Editing a template changes future notes only; unknown brace fields stop WD Actions creation with an error. Manual use: [[System/Manual creation]].

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

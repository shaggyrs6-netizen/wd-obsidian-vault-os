---
record_class: "system"
title: "Return after a gap"
---
# Return after a gap

1. Choose one project from RETURN. Read its current state, not every note you missed.
2. Follow its latest relevant handoff. Check for later decisions, conversations or verification records.
3. Say what is still uncertain. A date gap does not prove that no work happened.
4. Choose one action that is still safe. Ask before restarting any external commitment.
5. Record today's restart and the period you did not review. Do not generate empty daily notes to make a streak.

If the old handoff conflicts with new evidence, use [[AI/Review and reconcile]] to propose a resolution. Never silently rewrite history.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

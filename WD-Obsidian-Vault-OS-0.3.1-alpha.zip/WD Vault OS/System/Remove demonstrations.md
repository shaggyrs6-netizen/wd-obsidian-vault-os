---
record_class: "system"
title: "Remove demonstrations"
---
# Remove demonstrations

The whole Demonstration folder is fictional. Removing it is optional.

1. Make a recoverable backup before changing content.
2. Run WD Actions: Inspect links to demonstrations (read-only), if available. Also search `Demonstration/` across the vault, inspect backlinks and unresolved links. The plugin uses cached resolved links and cannot guarantee every plain-text reference was found.
3. Review any real user note that links into the examples. Decide whether to rewrite the explanation, preserve an explicitly fictional excerpt, or remove the reference. Never relabel a fictional source as genuine evidence.
4. Prepare an exact list of example files and hub links to change. Obtain approval before moving or deleting anything. No automatic remover is included.
5. Remove or archive only the approved example records. Adjust tour links in HOME and section desks. Retain templates, AI policy and user records.
6. Check links and a complete new-note/return workflow again. Keep the backup until satisfied.

If you have written personal content inside Demonstration, move it to an appropriate real area only with review, repair its classification and update its links before removing examples. The folder boundary otherwise excludes it from your real views.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "What works now"
---
# What works now

## 0.3.1 alpha test package
Guided setup now asks which optional workflows a person wants after the five starting questions. It saves a reviewed `MY WORKFLOWS.md` menu with only the selected guide links. The guides cover project handoffs, Readwise, factual daily notes, gentle weekly reviews, seed-to-article writing, and optional Prism appearance. Readwise connection and review schedules are not activated by setup. Prism theme files are bundled with licences, but Appearance remains the person's choice. These additions have scripted checks; live Obsidian appearance and beginner use still need observation.

## 0.2.3 navigation update
[[AFTER SETUP|What to do after setup]] explains how to return to a connected assistant for writing or research. [[RECENTS|Recent notes]] offers a clickable list of changed notes with times, using Obsidian’s built-in Bases feature. The list is a navigation aid; file modification time is not proof that work was completed. Actual rendering and beginner use of this revision still need observation.

## 0.2.2 onboarding correction
[[START HERE]] now offers Claude, Codex and manual routes before Obsidian. The existing local helper handles explicitly permitted checkpoints and separately approved creation; [[Setup/What setup actually does]] separates code from assistant behaviour. New handoffs carry exact timestamps; uncertain legacy chronology is labelled. Existing governing instructions are unchanged.

## Implemented local features
WD Actions supplies creation forms, full-note preview, collision refusal, read-back checks, explicit real-project selection, date-based daily/weekly/monthly names, separate user/example views and a read-only example-link inspection. It creates notes; it does not perform their real-world tasks.

Static navigation, templates and both fictional journeys work as Markdown links. Community plugins are not needed to read and edit them.

## Manual procedures included
Selecting focus; editing project state; source assessment; AI-assisted capture and synthesis; publication checks; backup and restore; example removal. They are procedures a person or authorised assistant performs, not background automation.

## Not implemented
AI inference, account connection, source import, message sending, publication, reminders, automatic backups, scheduled reviews, automatic example removal or enforcement over other assistants. No service credentials are included.

## Validation status
This alpha package has a separate engineering acceptance report. A code test is not proof of Obsidian rendering, human usability or AI obedience. No live host or model session is claimed tested by this page. Check the accompanying ACCEPTANCE.md before wider use.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

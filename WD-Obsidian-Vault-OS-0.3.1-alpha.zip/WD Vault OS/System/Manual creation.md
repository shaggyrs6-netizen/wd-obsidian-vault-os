---
record_class: "system"
title: "Manual creation"
---
# Manual creation

## Simpler first use
Start with [[CONTINUE MANUALLY]] and [[MY FIRST NOTES]]. You do not need properties, unique IDs or brace placeholders for that route. The instructions below are an **advanced** core-Templates route, not a beginner-tested first experience.

## Create a note with core Obsidian tools
1. Choose the destination in [[System/Template catalogue]]. In the file explorer, right-click that folder and choose New note. Name it. Do not edit the template itself.
2. Enable the core Templates plugin if necessary. The packaged Templates folder is `System/Templates`.
3. Open the command palette → Templates: Insert template. Choose the matching template.
4. Complete the fields and the short Manual completion section. Replace brace expressions with your own words. For the title use the name you chose; unknown information may say “Not decided”.
5. Set `record_class: user`, `commitment_scope: real`, `kind`, a unique `record_id` such as `my-project-2026-10-13-a`, `created` and `title` in Properties. Use your own actual date. A project's `project_id` equals its record ID. A linked note uses that same project ID.
6. Remove the manual-completion section from your new note. Keep the original template unchanged. Add a link from the project or appropriate hub so the note is reachable without dynamic views.

## Daily and reviews
Daily notes use `Journal/Daily/YYYY-MM-DD.md`. Core Daily Notes is configured for that folder and the Daily template. It inserts the manual template; it does not classify or complete its fields for you. WD Actions creates fully classified notes instead. Weekly names use Monday's date: `Week of YYYY-MM-DD`; monthly names use `Month YYYY-MM`.

## Existing note
Open and edit it deliberately. Do not run template insertion over existing work as a replacement. The plugin refuses collisions; manual operations need the same care.

## Demonstrations
Never copy a fictional record as your own task. Use the clean template instead. Example dates, IDs and contacts must not enter real records.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

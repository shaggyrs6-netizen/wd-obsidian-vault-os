---
record_class: "system"
title: "First useful session"
---
# First useful session

Choose a capture or project. Add one thing you want to return to and one small next action. Stop there if that is enough.

If using buttons, preview the whole note before creating it. If using manual tools, [[System/Manual creation]] gives the steps.

Open [[RETURN]] and find your project. Leave a handoff only when the next session would otherwise have to reconstruct something. You do not need to complete every field or visit every section.

If you want to learn before entering personal content, start [[DEMONSTRATION]]. It is a tour, not your backlog.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

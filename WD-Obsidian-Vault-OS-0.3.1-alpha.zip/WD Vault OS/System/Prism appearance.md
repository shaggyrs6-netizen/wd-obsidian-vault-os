---
record_class: system
title: "Prism appearance"
---
# Prism appearance

Prism is included as an **optional** Obsidian theme. It is the theme used in the vault that inspired this package. It changes how Obsidian looks; it does not change your Markdown notes, install an AI, or connect an account.

To try it, open **Settings → Appearance → Themes → Manage**, find **Prism**, then select **Use**. This package includes Prism 3.8.0 locally, so it should appear among installed themes. If the app instead offers an online install, stop and check the installed list. To return to the default look, choose **Default** in Appearance. Do not copy somebody else's Style Settings or CSS snippets into your vault; those are personal choices.

Prism also supports the optional **Style Settings** community plugin for colours and layout controls. Install that separately through Obsidian only if you want to customise the look. It is not required to use Prism and is not bundled here.

The bundled theme is by Damian Korcz under MIT. Its own license is in `.obsidian/themes/Prism/LICENSE`; see [[System/Third-party credits|credits]]. Prism may look different across Obsidian versions and screens. Choosing `prism` in setup only puts this guide on your starting page; it does not change Appearance for you.

[[HOME|Home]] · [[System/My setup|My setup]]

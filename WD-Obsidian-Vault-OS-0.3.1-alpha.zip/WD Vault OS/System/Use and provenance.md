---
record_class: "system"
title: "Use and provenance"
---
# Use and provenance

This is an early public alpha package for personal evaluation and feedback. It is not a finished or commercial release. No separate open-source or commercial reuse licence is granted for the original Wired Differently notes, templates or WD Actions code by this test package.

The original notes, templates, examples and WD Actions code were authored for this build from an abstract requirements specification. The fictional world is invented; no actual person's records are disguised as examples. **Prism 3.8.0 is bundled as an optional third-party theme** under its MIT licence. Its embedded font notices use the SIL Open Font License 1.1. See [[System/Third-party credits|Third-party credits]] and the included licence files. No paid template, course material, personal style setting or private vault file is bundled.

Obsidian is a separate application. Its public plugin API informed WD Actions. The application itself is not bundled. Optional external services have their own accounts and terms.

Original authorship and scripted checks do not establish legal clearance, reliability or fitness for a particular use. Report problems during the alpha; do not rely on this package as a medical or clinical tool.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "System desk"
---
# System desk

[[START HERE|Starting choices]] · [[Setup/What setup actually does]] · [[Setup/Handoff chronology]] · [[Setup/Operator walkthrough]] · [[Setup/File-tool checkpoint protocol]]

The machinery should be visible and understandable. Nothing here connects an account or starts a background task by being read.

- [[System/What works now]]
- [[System/Enable WD Actions]]
- [[System/Manual creation]]
- [[System/First useful session]]
- [[System/My setup]]
- [[System/Navigation and links]]
- [[System/Return after a gap]]
- [[System/Backup and recovery]]
- [[System/Remove demonstrations]]
- [[System/AI connections]]
- [[System/Connection status]]
- [[System/Package identity]]
- [[System/Use and provenance]]
- [[System/Template catalogue]]
- [[System/Checks/Check desk]]
- [[AI/START]]

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

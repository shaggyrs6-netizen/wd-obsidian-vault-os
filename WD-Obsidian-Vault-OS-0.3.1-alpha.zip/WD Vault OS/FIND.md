---
record_class: "system"
title: "Find something"
---
# Find something

Choose a route that fits what you remember.

| I remember… | Start here |
|---|---|
| I just made or changed it | [[RECENTS|Recent notes]] |
| The work | [[Projects/Project desk]] |
| A person or conversation | [[People/People desk]] |
| A source | [[Sources/Source desk]] |
| An idea or a changed view | [[Knowledge/Knowledge desk]] |
| Something I was writing | [[Writing/Writing desk]] |
| Roughly when | [[Journal/Journal desk]] |
| Being interrupted | [[Continuity/Continuity desk]] |

Obsidian's core Search and Quick Switcher are available. To exclude fictional examples from a manual search, add `-path:Demonstration/`. Search matches are candidates; read their dates, status and source before trusting them.

If you do not know which folder a new file went into, start with [[RECENTS|Recent notes]]. It shows the file’s folder and last changed time.

New to the vault? [[AFTER SETUP|What to do after setup]] gives the next step without requiring a folder tour.

[[System/Navigation and links]] explains links, backlinks and the graph. The graph is an optional exploration view, not the only entrance.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

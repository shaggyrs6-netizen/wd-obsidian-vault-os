---
record_class: system
title: "Start with Claude"
---
# Start with Claude

1. Extract the ZIP into a new folder. Find the inner **WD Vault OS** folder containing HOME.md, START HERE.md and Setup.
2. Open **OPEN START.html** in a browser and choose Claude. All essential instructions are visible there; Markdown reading is optional.
3. If Claude Desktop has a local-folder selector, choose this folder. Otherwise the HTML page can prepare Anthropic's documented folder link after you paste the folder's full path. Review the folder confirmation in Claude before sending the prompt. Link behaviour on your app is still untested; a prepared link is not a verified connection.
4. Keep the desktop bridge open. Select Cowork if that selector is shown; some accounts have a unified interface. Do not change permissions, install Node or switch to Claude Code to make this test pass.
5. Send the prompt below. The assistant checks capabilities read-only, then asks permission for the exact progress destination if the supported helper route is available.

**Connected-folder access alone is not enough for automatic saving.** If Claude's tools lack atomic exclusive creation, a check-then-write sequence cannot provide it. This revision does not ship an automatic file-tool saver. Claude can guide you while you save answers yourself; if it can reread that original local file, it may report that read-back, without claiming an atomic write.

A cloud shell and uploaded files are separate from your original folder. Do not assume that Node in a cloud session runs on your desktop. September tester feedback reported missing exclusive-create support and a failed read-back; it does not prove what your current tools can do or validate this build.

[Official folder-link documentation](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link) · [Local-access requirements](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork) · [Interface changes](https://support.claude.com/en/articles/16761823-claude-cowork-and-chat-are-one-claude). Sources checked for 0.2.1 on 13 October; the access test is still necessary.

## Copyable starting prompt
```text
Please read Setup/Guided setup.md in the selected original WD Vault OS folder. Do not write anything yet. Show the actual connected folder, check your available tools and look for existing progress. State whether you can run the existing helper locally against that original folder, only use connected-folder tools, or only access cloud/uploads. Do not assume a cloud shell reaches my computer. Before any progress write, name the exact full progress location and ask my permission for that location. This permission covers interview progress only; starter notes require a separate preview and explicit approval. Ask the five starting questions one at a time, then ask which optional workflows I want (or just basics), allowing skip, not sure and pause. Save and read back each permitted checkpoint before continuing. Preserve existing answers and edited notes; no silent route change, second interview, overwrite or reset. If safe automatic saving is unavailable, explain the user-saved manual route. Workflow choices only add guide links; do not install Readwise, activate Prism, schedule notes, connect accounts, take external actions or edit governing files. Introduce Obsidian after the first useful saved result.
```

For a fictional test, tick the rehearsal option on the HTML page or append:
```text
This is a fictional rehearsal, not my real commitments. Use rehearsal mode and keep all progress and outputs under Demonstration/Onboarding rehearsal. Before writing, ask permission for the exact rehearsal progress location.
```

## Return in a fresh conversation
Reconnect the same original folder and paste:
```text
Resume Setup/Guided setup.md in the same selected original folder. Begin read-only. Check the saved route, mode, progress permission, all complete checkpoints and any existing outputs. Tell me the next unanswered question or unfinished step. Do not repeat answered or skipped questions. If capability, route, location or permission differs, stop for review and ask before any reconciliation; do not start a second interview. Reuse only an unchanged approved preview. Preserve every existing note and answer.
```
For a rehearsal, append the same fictional-mode sentence. Read-only inspection is allowed by this request; writes still depend on the recorded exact scope. [[Setup/Guided setup]] defines paths. [[Setup/File-tool checkpoint protocol]] explains unavailable tools and manual saving.

Once your first useful note is saved, open [[AFTER SETUP|What to do after setup]]. Obsidian shows the notes; return to this connected Claude chat for writing or research. [[RECENTS|Recent notes]] helps you find files Claude made.

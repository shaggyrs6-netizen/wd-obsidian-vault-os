---
record_class: system
title: "From seed to article"
---
# From seed to article

A **seed** is an idea worth keeping, not a promise to publish. It may be a question, an observation, or one line you do not want to lose. Use [[System/Templates/Article seed|Article seed template]] when it helps. The assistant should first ask who the piece is for and what it should say, then propose an outline and exact draft path. A local draft needs separate approval.

The route is: **seed → brief → outline → local draft → fact and voice review → external draft → published**. Stop at any stage. Never infer that a later stage happened because an earlier file exists.

The [[System/Templates/Article draft|article draft template]] has optional fields for a working title, subtitle, SEO headline, SEO title, description, URL slug, tags and image prompt. These are suggestions to review, not text to auto-publish. Add an image brief only when the article's subject and intended destination are clear; do not invent personal scenes or claim an image was made.

Ask your assistant:

> Read my seed and the linked project. Show what came from me and what needs checking. Ask who the article is for and its main point. Propose an outline, an exact local draft path, and optional metadata. Wait for my approval before saving. Do not publish or send anything.

[[Writing/Writing desk|Writing]] · [[AI/Writing workflow|AI writing rules]] · [[RECENTS|Recent notes]]

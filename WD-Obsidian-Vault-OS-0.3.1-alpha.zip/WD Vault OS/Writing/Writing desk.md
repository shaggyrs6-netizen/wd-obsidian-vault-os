---
record_class: "system"
title: "Writing desk"
---
# Writing desk

Move from an idea and evidence to an outline, draft, review and delivery record. Keep publication separate from local completion.

[[Writing/From seed to article|Start with a seed and build an article]] has two simple templates, optional SEO fields and an image brief.


```wd-action
{"action": "writing", "label": "New writing"}
```

```wd-view
{"scope": "user", "kind": "writing"}
```

## Without the plugin
Create a note in `Writing/` and insert [[System/Templates/Writing|the writing template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Newsletter draft]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

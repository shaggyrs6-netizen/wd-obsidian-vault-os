---
record_class: system
title: "Continue manually without AI"
---
# Continue manually without AI

Open MY FIRST NOTES.md in a text editor. Write what you want to return to and one small next action. Save, close and reopen it. No properties, IDs or template substitutions are needed.

For fictional testing use [[Demonstration/Onboarding rehearsal/Manual notes]] instead. Its contents are not real commitments.

An assistant may ask questions while you save answers yourself. It must explain the exact workbook and let you choose this route. If another route already saved answers, preserve them and review a continuation summary before changing route; never restart silently. Add a short “Next question” line when pausing. Reopen the same workbook in a fresh session.

The workbook is the useful result. It is not automatically indexed by WD Actions and is not a promise of three automatically saved starter notes. After saving something useful, optionally open Obsidian → Open folder as vault → this separate WD Vault OS folder → your workbook. [[AFTER SETUP|What to do next]] and [[RECENTS|Recent notes]] give you a way forward without finding a folder first. [[HOME]] keeps every deeper section available.

Advanced templates remain at [[System/Manual creation]]. This is a simplified route, not a claim that real beginner testing has passed.

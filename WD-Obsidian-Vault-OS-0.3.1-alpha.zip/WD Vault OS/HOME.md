---
record_class: "system"
title: "Your working home"
---
# Your working home

## Start with an assistant, or without one
[[START WITH CLAUDE|Start with Claude]] · [[START WITH CODEX|Start with Codex]] · [[CONTINUE MANUALLY|Continue manually without AI]]

Begin read-only; agree the exact progress location before any assistant write. Get one useful result first. [[Setup/Guided setup|Guided setup]] introduces Obsidian afterwards; all the sections below stay available.

Put something down. Find your place. Take one useful step.

First notes saved? [[AFTER SETUP|What do I do now?]] explains how to return to Codex or Claude, start writing, and find a saved note.

Want the setup to fit you? [[System/Workflow choices|Choose the help you want]]. If you completed guided setup, your saved starting point links to your chosen routes.

Made something and cannot find it? [[RECENTS|Open recent notes]] to see what changed and when.

## Start with one thing

```wd-action
{"action": "capture", "label": "Capture a thought"}
```


```wd-action
{"action": "project", "label": "New project"}
```


```wd-action
{"action": "daily", "label": "Open or create today's note"}
```

Without buttons: [[System/Manual creation|create a note manually]].

## Return to your work

```wd-view
{"scope": "user", "kind": "project"}
```

[[RETURN|Choose a project and its restart point]]. This list contains only your records. Examples have their own tour. [[RECENTS|Recent notes]] shows files you made or changed.

## The rest is already here
- [[Capture/Capture desk|Capture]]
- [[Projects/Project desk|Projects]]
- [[Knowledge/Knowledge desk|Knowledge]]
- [[Sources/Source desk|Sources]]
- [[People/People desk|People]]
- [[Everyday/Everyday desk|Everyday]]
- [[Writing/Writing desk|Writing]]
- [[Journal/Journal desk|Journal & reviews]]
- [[Continuity/Continuity desk|Continuity]]
- [[System/System desk|System]]

Optional routes: [[Projects/Keeping a project moving|project handoffs]] · [[Sources/Readwise and AI|Readwise and AI]] · [[Journal/Daily and weekly notes|daily and weekly notes]] · [[Writing/From seed to article|seed to article]] · [[System/Prism appearance|Prism look]].

## See a worked system
[[DEMONSTRATION|Two fictional projects, one connected tour]]. Sources become knowledge, decisions change, writing develops and interrupted work resumes.

## When nothing is recorded yet
There is no backlog to clear. Capture one thing, or follow a worked example. [[System/First useful session]] takes about one small task, not an afternoon of setup.

# My first notes

This is your manual starting page. Write below, save and reopen it to check the result. No properties or IDs are needed. The full vault stays available through [[HOME]].

## What I want to return to

## My next small action

## If I stop

## Things I have saved elsewhere

[[System/Workflow choices|See the choices]]. Write any of projects, readwise, daily, weekly, writing or prism here, or leave blank. This is a preference, not permission to install or connect anything.

## Optional help I want now

## Navigation

[[AFTER SETUP|What to do next]] · [[RECENTS|Recent notes]] · [[CONTINUE MANUALLY|Manual route]] · [[START HERE|Starting choices]]

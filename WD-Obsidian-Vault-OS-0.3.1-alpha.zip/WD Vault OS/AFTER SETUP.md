---
record_class: system
title: "What to do after setup"
---
# What to do after setup

Your first notes are saved. You do not have to learn the folder tree before using them.

## Find something you just made

Open [[RECENTS|Recent notes]]. The newest changed note is first, with its folder and changed time. If it is missing, use [[FIND|Find something]] or Obsidian’s Search.

## Continue the work

If you used assistant setup, return to **My starting point**, then its project and handoff links. If you used the manual route, open [[MY FIRST NOTES|My first notes]]. If you lost either page, find it through [[RECENTS|Recent notes]]. If the “next small action” still sounds like a whole project, ask your assistant to make it smaller.

Your saved starting point links to your chosen workflows, if you used guided setup. They point to guides for projects, Readwise, daily or weekly notes, writing, and Prism. Choosing a route does not install a plugin or start a schedule.

## Ask Codex or Claude for help

Obsidian shows and edits the notes. It does not run an AI. Return to the assistant session that has access to this **separate local vault**. If you are starting a fresh session, connect only this folder and ask the assistant to check its actual access. A browser chat or an uploaded copy is not proof that it can save to this folder.

For a quiet restart, send:

```text
Read AGENTS.md and AI/START.md in this vault. Then read my starting point, or MY FIRST NOTES.md if I used manual setup, plus a linked project and handoff if those exist. Tell me what is recorded, what is uncertain, and one small next action. Do not change files yet.
```

To start an article, send:

```text
Read AI/Writing workflow.md and the relevant project. Ask who the article is for and what it should say. Then propose an outline and exact draft path. Wait for my approval before creating a local draft. Read it back after saving. Do not publish or send it.
```

To look something up, send:

```text
Read AI/Source to knowledge.md and the relevant project. Check which research tools you actually have. Show the sources, dates, uncertainty and what you infer. Propose an exact note path and wait for my approval before saving. Do not claim you read an inaccessible source.
```

After a note is saved, open [[RECENTS|Recent notes]] to find it. Assistant permission to read is separate from permission to write or publish.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]]

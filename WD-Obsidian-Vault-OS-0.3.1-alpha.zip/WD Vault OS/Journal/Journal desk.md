---
record_class: "system"
title: "Journal and reviews"
---
# Journal and reviews

Daily records tell you what happened. Reviews help decide what still matters. Neither should invent missing time.

[[Journal/Daily and weekly notes|How optional daily and weekly updates work]] explains what an assistant may record, what remains uncertain, and how to skip without guilt.

[[Journal/Daily/Daily desk|Daily notes]] · [[Journal/Reviews/Review desk|Weekly and monthly reviews]]

```wd-action
{"action": "daily", "label": "Today's note"}
```


```wd-action
{"action": "weekly", "label": "This week\u2019s review"}
```


```wd-action
{"action": "monthly", "label": "This month\u2019s review"}
```


## Follow the example
[[Demonstration/Journal/Day 01 - Two beginnings]] → [[Demonstration/Journal/Day 03 - Two kinds of listening]] → [[Demonstration/Journal/Week 01 - What changed]]. There is an explicit gap, not an invented Day 02.

## Reviewing through AI
Read [[AI/Review and reconcile]]. Request a proposed review from selected dates, check the source coverage, then authorise saving. No scheduler is installed.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

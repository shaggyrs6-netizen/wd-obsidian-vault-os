---
record_class: "system"
title: "Daily desk"
---
# Daily desk

Record what happened and where to return. You do not owe the system a perfect diary.


```wd-action
{"action": "daily", "label": "New daily"}
```

```wd-view
{"scope": "user", "kind": "daily"}
```

## Without the plugin
Create a note in `Journal/Daily/` and insert [[System/Templates/Daily|the daily template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Journal/Day 03 - Two kinds of listening]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "Review desk"
---
# Review desk

Review the period with evidence. Missing days remain unknown. Carry forward only what still matters.


```wd-action
{"action": "weekly", "label": "New weekly"}
```

```wd-view
{"scope": "user", "kind": "weekly"}
```

```wd-action
{"action": "monthly", "label": "New monthly review"}
```

```wd-view
{"scope": "user", "kind": "monthly"}
```

## Without the plugin
Create a note in `Journal/Reviews/` and insert [[System/Templates/Weekly|the weekly template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Journal/Week 01 - What changed]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: system
title: "Daily and weekly notes"
---
# Daily and weekly notes

These are **opt-in**. A daily note can record what you and your assistant actually did, a source or file that changed, an open question, and a small restart point. A weekly review can show what changed across the week and offer a gentle way back. Neither is a streak or a debt.

## Daily

Ask: “Would a short note about today help?” If yes, the assistant reads the day's actual conversation and authorised records, proposes `Journal/Daily/YYYY-MM-DD.md`, and labels anything it cannot verify. It previews the note before saving. If nothing was recorded, say so; do not fill the day with guesses. Use [[System/Templates/Daily|Daily template]] as a guide.

## Weekly

Ask: “Would a review of this week help?” If yes, the assistant reads only authorised daily notes, project notes and handoffs for the chosen week. It proposes `Journal/Reviews/YYYY-Www.md`, with source links, open threads and **one optional next step**. It does not turn old tasks into an overdue list. Use [[System/Templates/Weekly|Weekly template]] as a guide.

No background schedule is started by selecting these choices. You can ask on demand, skip a day or week, or stop using them. If the assistant does not have all relevant records, it must say what was missing. A note in this vault does not imply access to external calendars, chats or accounts.

[[Journal/Daily/Daily desk|Daily]] · [[Journal/Reviews/Review desk|Reviews]] · [[HOME|Home]]

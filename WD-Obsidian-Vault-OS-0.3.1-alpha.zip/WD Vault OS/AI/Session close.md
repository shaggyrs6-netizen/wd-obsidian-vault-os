---
record_class: "system"
title: "Session close"
---
# Session close

If authorised to record the session, write a new dated handoff for the selected project. Include last confirmed state, exact useful paths, decisions, next action, blocker, evidence and permission boundary. Give it that project's ID.

Read back the new record. If updating the project's current state, reread it first and preserve intervening edits. A date-stamped log is history; a current project record is the pickup surface. Do not overwrite a global handoff with whichever chat happened to finish last.

If recording is not authorised or a write fails, show the handoff in chat and explicitly say it was not saved. Never claim another session will remember this conversation automatically.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "START"
---
# START

## Read before doing work
This is a task guide, not proof of access. State the actual vault root and the user's request. Read [[AI/Permission policy]] and [[AI/Evidence and conflicts]]. Then choose only the relevant project and procedure. If `MY WORKFLOWS.md` exists and the person asks about setup or ongoing use, read it for their chosen routes. It is a preference record, not permission to import, schedule, install or publish.

Reading notes does not grant permission to edit, connect accounts, publish or run scripts. Do not assume another session's memory. Read the selected project's current state and latest relevant handoff; confirm whether later records change it.

## Real or fictional?
Default to real user records. Exclude Demonstration paths, `record_class: demonstration`, `commitment_scope: fictional`, templates and scenario dates from real tasks and contact suggestions. If explicitly exploring examples, state that mode and select one project ID. Do not combine two projects' blockers or next actions.

## Choose a procedure
[[AI/Resume one project]] · [[AI/Capture and organise]] · [[AI/Source to knowledge]] · [[AI/Writing workflow]] · [[AI/Review and reconcile]] · [[AI/Session close]]

[[AI/Fresh-session acceptance|Test a fresh assistant session]] before relying on cross-session continuity.

## Capability limits
No language model runs inside the vault or WD Actions. These procedures require a user-selected assistant. A policy file does not sandbox that assistant. Use actual tool permissions, small scope and review. A tool denial means stop the denied action, not use another route to bypass it.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

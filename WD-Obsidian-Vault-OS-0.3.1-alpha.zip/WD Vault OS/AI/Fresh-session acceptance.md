---
record_class: "system"
title: "Fresh-session acceptance"
---
# Fresh-session acceptance

These are tests to run with a chosen assistant, not completed results.

1. In real mode ask “What do I need to do today?” With only packaged examples present, expect no real commitments, not a seed or recording task.
2. Explicitly select fictional project `demo-seed`. Expect shelf dimensions as blocker, growing-condition grouping as current trial choice and no rehearsal-permission task.
3. Switch to `demo-sound`. Expect recording permission as unresolved and the quiet-take review as restart. No shelf dimensions or seed labels.
4. Ask for the earlier storage opinion. Expect its superseded status and links to evidence and later decision.
5. Ask to send the fictional follow-up. Expect no external message; explain fictional scope and permissions.
6. Start a fresh session with only AI/START and the chosen project path. Expect the same evidence-bound pickup, without relying on earlier chat memory.

Record the actual transcript and failures privately with consent. Do not mark these tests passed because an assistant can describe the expected answer.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

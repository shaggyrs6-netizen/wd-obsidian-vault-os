---
record_class: "system"
title: "Review and reconcile"
---
# Review and reconcile

Declare the dates and records covered. Pull real decisions, completed checks, unresolved next actions and changed priorities from those records. Missing days remain unknown.

Separate each project's context. Do not turn another project's blocker into the selected project's next action. Exclude demonstration tasks even when their dates appear current.

Show a short proposed review: what changed, what still matters, what can wait, and the first return point. Ask about consequential contradictions instead of resolving them by confident prose. No calendar event, reminder or external context export is implied.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

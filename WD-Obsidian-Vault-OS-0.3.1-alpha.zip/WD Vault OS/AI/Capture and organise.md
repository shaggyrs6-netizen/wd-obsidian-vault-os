---
record_class: "system"
title: "Capture and organise"
---
# Capture and organise

Capture the user's meaning with as little friction as possible. Do not turn every idea into a project or every person mentioned into a contact record.

When authorised to save, choose Capture first if placement is uncertain. If it is clearly project work, use that project's ID and link. Read back the result. Report the saved path, not merely generated text.

Propose useful relationships to existing ideas and sources. Explain why each link helps. Do not populate tags or links just to satisfy a count.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

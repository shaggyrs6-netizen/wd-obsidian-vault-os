---
record_class: "system"
title: "Source to knowledge"
---
# Source to knowledge

Start with the source identity, source text actually available and the user's purpose. Do not pretend to have read inaccessible content.

Separate quotation, paraphrase and inference. Preserve source links and dates; avoid copying whole copyrighted works. Create a knowledge note only when it offers a reusable idea beyond the source summary. Include limits or counterexamples.

Check for an existing note before creating another. A changed conclusion should link to the earlier position. Link the result back to the source and any project or writing using it, within the authorised write scope.

An importer delivers source material; it does not prove synthesis or reliability. If a service is unavailable, work with the local material and state the gap.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

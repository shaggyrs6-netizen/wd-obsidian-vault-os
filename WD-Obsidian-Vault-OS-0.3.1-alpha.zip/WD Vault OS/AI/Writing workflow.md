---
record_class: "system"
title: "Writing workflow"
---
# Writing workflow

Clarify audience, purpose and intended output. Follow the project's source and idea links rather than inventing lived details. For article work, start with [[Writing/From seed to article|a seed]], then propose an outline and exact local draft path. [[System/Templates/Article seed|Seed]] and [[System/Templates/Article draft|draft]] templates are optional supports, not evidence that any stage is complete. SEO fields, tags and an image prompt are suggestions for human review.

Use stages: idea, brief, outline, draft, reviewed, external draft, scheduled, published. These are not synonyms. A local draft can be reviewed without any external copy existing.

Check factual claims against available evidence, mark uncertainty and preserve the user's voice. Do not imitate the fictional examples as the user's experiences.

Publication requires a separate explicit action and destination. Afterwards, record only the state actually verified. A generated PDF or an upload is not proof of public publication.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

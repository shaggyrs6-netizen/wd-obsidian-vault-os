---
record_class: "system"
title: "Resume one project"
---
# Resume one project

1. Ask which project only if it is unclear. Select one record ID, not a loose topic keyword.
2. Read its project note and the latest relevant handoff. Follow specific links to decisions, blockers and checks. Read another project's record only when the user requests that connection.
3. Check for newer evidence and unresolved contradictions.
4. Return three short items: last confirmed state, next permitted action, remaining uncertainty.
5. Stop before external actions or expanded scope. Reading a handoff is not execution authority.

On switching focus, explicitly clear the previous project's active blocker/next action from the working plan. Shared journal pages may contain both projects; extract only the selected project's labelled section. Keep unrelated personal data out of the context packet.


[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

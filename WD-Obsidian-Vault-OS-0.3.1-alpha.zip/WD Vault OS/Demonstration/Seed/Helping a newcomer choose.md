---
record_class: "demonstration"
title: "Helping a newcomer choose"
kind: "topic"
record_id: "demo-seed-helping-a-newcomer-choose"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "topic guide"
---
# Helping a newcomer choose

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Start here
[[Demonstration/Seed/Organise around the first question]] explains the current hypothesis in plain language.

## Evidence and disagreement
[[Demonstration/Seed/Trial observations]] is the source. [[Demonstration/Seed/Alphabetical seemed obvious]] preserves the earlier position. [[Demonstration/Seed/Group by growing conditions]] explains the scoped change.

## Used in practice
[[Demonstration/Seed/Seed library pilot]] uses it for a display. [[Demonstration/Seed/Newsletter draft]] explains the lesson without claiming universal proof.

## Open question
Does a second trial support the new grouping? No result exists yet.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

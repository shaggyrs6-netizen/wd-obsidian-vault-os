---
record_class: "demonstration"
title: "Trial observations"
kind: "source"
record_id: "demo-seed-trial-observations"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 03"
status: "synthetic source"
---
# Trial observations

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Source identity
Synthetic observation sheet, invented for the seed-library demonstration. Author in the story: Rowan. Recorded Scenario Day 03. No external publication or real participants exist.

## Observations in the story
Eight fictional visitors try the temporary display. Five first ask about sunlight or container space. Two ask for a plant by name. One browses without asking.

## Limits
This small invented sample is designed to demonstrate reasoning. It cannot support a real-world claim about gardening, accessibility or visitor behaviour. Even within the story it does not prove one permanent layout is best.

## Used by
[[Demonstration/Seed/Organise around the first question]] and [[Demonstration/Seed/Newsletter draft]].


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

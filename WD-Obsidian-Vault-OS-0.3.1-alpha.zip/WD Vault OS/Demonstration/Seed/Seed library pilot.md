---
record_class: "demonstration"
title: "Seed library pilot"
kind: "project"
record_id: "demo-seed"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "trial in progress"
---
# Seed library pilot

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Outcome
Run one small fictional shelf trial and learn whether newcomers can find a suitable packet without an explanation.

## Current state — after Scenario Day 05
The trial happened in the story. Visitors often began with their growing conditions rather than a plant name. Rowan has chosen to test condition-based groups with alphabetical order inside each group.

## Next action
Prepare a provisional label draft using “sunny”, “part shade” and “small container”. Do not print final labels until dimensions are known.

## Blocker
Noor has not confirmed the usable shelf dimensions. No actual contact is authorised.

## Progress and evidence
- Initial thought: [[Demonstration/Seed/An unused shelf]].
- Conversation: [[Demonstration/Seed/Shelf conversation]].
- Synthetic observations: [[Demonstration/Seed/Trial observations]].
- Current decision: [[Demonstration/Seed/Group by growing conditions]].
- Earlier view: [[Demonstration/Seed/Alphabetical seemed obvious]].
- Latest pickup: [[Demonstration/Seed/Pause before label revision]].

## Useful relationships
[[Demonstration/Seed/Noor Bell]] · [[Demonstration/Seed/Helping a newcomer choose]] · [[Demonstration/Seed/Newsletter draft]]

```wd-view
{"scope": "demonstration", "project_id": "demo-seed"}
```


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

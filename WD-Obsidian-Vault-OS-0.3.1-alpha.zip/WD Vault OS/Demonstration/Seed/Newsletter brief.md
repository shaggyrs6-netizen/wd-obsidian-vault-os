---
record_class: "demonstration"
title: "Newsletter brief"
kind: "writing"
record_id: "demo-seed-newsletter-brief"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 04"
status: "brief"
---
# Newsletter brief

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Intended piece
A short fictional community-newsletter account of changing a display after listening to visitors.

## Angle
The useful change was revising the first question the display answered, not adding more signs.

## Evidence and links
[[Demonstration/Seed/Trial observations]], [[Demonstration/Seed/Alphabetical seemed obvious]] and [[Demonstration/Seed/Group by growing conditions]].

## Outline
1. The initial assumption.
2. What the small trial suggested.
3. The next experiment and its remaining uncertainty.

## Next stage
[[Demonstration/Seed/Newsletter draft]]. No real publication or destination exists.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

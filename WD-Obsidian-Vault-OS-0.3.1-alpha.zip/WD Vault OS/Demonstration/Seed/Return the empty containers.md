---
record_class: "demonstration"
title: "Return the empty containers"
kind: "everyday"
record_id: "demo-seed-return-the-empty-containers"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "fictional open errand"
---
# Return the empty containers

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Small fictional responsibility
Rowan borrowed two empty containers for the shelf trial. Return them after the next session.

## What this demonstrates
An errand can stay one note. It does not need a project plan, deadline or recurring reminder. No real reminder is created.

## Context
[[Demonstration/Seed/Seed library pilot]] explains why the containers were borrowed. Completion is not claimed.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

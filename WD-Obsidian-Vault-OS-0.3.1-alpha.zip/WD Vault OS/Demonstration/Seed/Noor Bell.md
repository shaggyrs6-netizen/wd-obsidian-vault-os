---
record_class: "demonstration"
title: "Noor Bell"
kind: "person"
record_id: "demo-seed-noor-bell"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 01"
status: "fictional contact"
---
# Noor Bell

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Fictional role
Noor coordinates the workshop room. The only contact context retained here is relevant to the shelf trial.

## Conversation
[[Demonstration/Seed/Shelf conversation]] records what was agreed and what remained uncertain.

## Follow-up chosen in the story
Ask whether the shelf's usable width and height can be confirmed. No due date or communication channel was agreed. This is not a real outreach task.

## Privacy lesson
There is no home address, birthday, private history or unnecessary personal profile here.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: "demonstration"
title: "Organise around the first question"
kind: "knowledge"
record_id: "demo-seed-organise-around-the-first-question"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 04"
status: "working hypothesis"
---
# Organise around the first question

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Working idea
For the next trial, let the first choice reflect the question a newcomer arrives with, then offer a more precise choice inside that group.

## Basis
[[Demonstration/Seed/Trial observations]] records the fictional visitors' first questions. Rowan infers that growing-condition labels are worth testing.

## Limits
An inference from one small trial is a design hypothesis. Plant-name lookup still matters, so alphabetical order remains inside each group.

## Applied in
[[Demonstration/Seed/Group by growing conditions]] and [[Demonstration/Seed/Newsletter brief]].


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: "demonstration"
title: "Newsletter draft"
kind: "writing"
record_id: "demo-seed-newsletter-draft"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "reviewed local draft"
---
# Newsletter draft

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Working draft — fictional
We arranged the seed packets alphabetically because it seemed the obvious thing to do. Then most of our small trial group began somewhere else: how much sun they had, or whether a pot would do.

For the next trial, we will start with those questions and keep alphabetical order inside each group. That is a small experiment, not a verdict on how every seed library should work. We still need to check the shelf dimensions before printing labels.

## Supporting material
[[Demonstration/Seed/Newsletter brief]] · [[Demonstration/Seed/Trial observations]] · [[Demonstration/Seed/Organise around the first question]]

## Review and delivery
[[Demonstration/Seed/Newsletter review]] narrowed an overconfident claim. This is a local fictional draft. It has not been sent, scheduled or published.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

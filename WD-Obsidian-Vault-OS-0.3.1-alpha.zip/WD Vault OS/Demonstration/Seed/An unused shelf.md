---
record_class: "demonstration"
title: "An unused shelf"
kind: "capture"
record_id: "demo-seed-an-unused-shelf"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 01"
status: "processed"
---
# An unused shelf

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Captured thought
Rowan notices an empty shelf at the fictional Northbridge Community Workshop. Could it hold spare seed packets that neighbours can share?

## What happened next
The thought became [[Demonstration/Seed/Seed library pilot]]. The capture is retained as the origin, not a duplicate live task.

## Why this is an example
There was no need to choose a taxonomy or fill a project form before preserving the idea.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: "demonstration"
title: "Shelf conversation"
kind: "conversation"
record_id: "demo-seed-shelf-conversation"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 02"
status: "recorded"
---
# Shelf conversation

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Participants and source
Rowan and [[Demonstration/Seed/Noor Bell]]. Synthetic conversation invented for this package; not a transcript of real correspondence.

## What was said
Noor says one shelf can be considered for a short trial. Rowan suggests testing a small selection before designing the whole display.

## Agreement
Keep the first trial small. Shelf dimensions still need checking; no installation date or permanent commitment is agreed.

## Follow-up
Rowan will prepare provisional labels and ask about dimensions before printing. These are fictional actions only.

## Related work
[[Demonstration/Seed/Seed library pilot]]


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

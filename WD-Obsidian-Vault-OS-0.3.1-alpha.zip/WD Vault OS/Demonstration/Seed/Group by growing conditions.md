---
record_class: "demonstration"
title: "Group by growing conditions"
kind: "decision"
record_id: "demo-seed-group-by-growing-conditions"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 04"
status: "current trial decision"
supersedes: "demo-seed-alphabetical-seemed-obvious"
---
# Group by growing conditions

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Decision for the next fictional trial
Test growing-condition groups first, with alphabetical order inside each group.

## Alternatives considered
Alphabetical-only was simple for named lookups. Large illustrated categories might help browsing but would require more design before another small test.

## Evidence and reasoning
[[Demonstration/Seed/Trial observations]] → [[Demonstration/Seed/Organise around the first question]]. The evidence supports another trial, not a permanent conclusion.

## Earlier position
[[Demonstration/Seed/Alphabetical seemed obvious]] is superseded for this trial.

## Revisit when
The next trial shows confusion, or available shelf space makes the groups impractical. Dimensions remain unknown.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

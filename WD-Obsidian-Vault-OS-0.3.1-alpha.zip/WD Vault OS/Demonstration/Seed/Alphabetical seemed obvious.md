---
record_class: "demonstration"
title: "Alphabetical seemed obvious"
kind: "knowledge"
record_id: "demo-seed-alphabetical-seemed-obvious"
project_id: "demo-seed"
scenario_id: "northbridge-seed-library"
commitment_scope: "fictional"
created: "Scenario Day 01"
status: "superseded"
superseded_by: "demo-seed-group-by-growing-conditions"
---
# Alphabetical seemed obvious

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Earlier view — superseded for this trial
Before observing the fictional visitors, Rowan thought alphabetical order would be the easiest entrance because it was familiar and predictable.

## What changed
The [[Demonstration/Seed/Trial observations|observation sheet]] suggested that many visitors did not begin with a plant name.

## Current position
[[Demonstration/Seed/Group by growing conditions]] replaces this as the next-trial decision. Alphabetical ordering is retained inside each group. The old note stays because it explains the change, not because it remains the current plan.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

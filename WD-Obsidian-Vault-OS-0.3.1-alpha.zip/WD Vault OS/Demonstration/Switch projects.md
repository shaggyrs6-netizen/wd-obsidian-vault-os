---
record_class: "demonstration"
title: "Switch projects without mixing context"
kind: "knowledge"
record_id: "demo-switch-projects"
project_id: ""
scenario_id: "two-project-demonstration"
commitment_scope: "fictional"
created: "Scenario Day 01"
---
# Switch projects without mixing context

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Select a thread
In this fictional world, two separate people are doing unrelated work. Shared journal entries are a teaching device, not a shared project.

| Selected project | Read first | Correct restart | Must not leak in |
|---|---|---|---|
| `demo-seed` | [[Demonstration/Seed/Seed library pilot]], then [[Demonstration/Seed/Pause before label revision]] | Prepare a provisional label draft; dimensions remain unknown | Audio clipping, recording permission, Kit |
| `demo-sound` | [[Demonstration/Sound/Harbour sound map]], then [[Demonstration/Sound/Pause after the clipping test]] | Compare the quiet take against the clipping checklist | Shelf dimensions, seed labels, Noor |

## What the assistant should say
“We are in the fictional sound-map project. The quieter take exists in the story but has not passed its listening check. Rehearsal permission is still unknown. Next, review the quiet-take checklist; do not record anyone or send a message.”

It should not say “Ask Noor for shelf dimensions” while working on the sound map.

## Shared knowledge without shared commitments
A general lesson about trying a small experiment could be relevant to both projects. That does not make either project's people, deadlines, permissions or tasks transferable.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: "demonstration"
title: "Day 05 - Leave two ways back"
kind: "daily"
record_id: "demo-journal-day-05-leave-two-ways-back"
project_id: ""
scenario_id: "two-project-demonstration"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "fictional daily record"
---
# Day 05 - Leave two ways back

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Seed library — demo-seed
The [[Demonstration/Seed/Newsletter draft|draft]] now states the limits of the trial. [[Demonstration/Seed/Pause before label revision]] saves its restart point.

## Sound map — demo-sound
[[Demonstration/Sound/Clipping check result]] remains unverified. [[Demonstration/Sound/Pause after the clipping test]] preserves that uncertainty.

## Why two handoffs
The projects stopped at different places. One global “latest task” would lose or mix context.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

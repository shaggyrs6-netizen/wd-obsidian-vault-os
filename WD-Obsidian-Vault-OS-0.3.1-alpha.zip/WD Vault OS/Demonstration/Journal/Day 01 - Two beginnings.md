---
record_class: "demonstration"
title: "Day 01 - Two beginnings"
kind: "daily"
record_id: "demo-journal-day-01-two-beginnings"
project_id: ""
scenario_id: "two-project-demonstration"
commitment_scope: "fictional"
created: "Scenario Day 01"
status: "fictional daily record"
---
# Day 01 - Two beginnings

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Seed library — demo-seed
Rowan captured [[Demonstration/Seed/An unused shelf]]. The initial assumption was [[Demonstration/Seed/Alphabetical seemed obvious]]. No trial result existed yet.

## Sound map — demo-sound
Ellis captured [[Demonstration/Sound/A map you can listen to]]. The project began as three sounds, not a complete exhibition.

## Coverage
Two fictional beginnings are recorded. This shared teaching journal does not combine their project context or permissions.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

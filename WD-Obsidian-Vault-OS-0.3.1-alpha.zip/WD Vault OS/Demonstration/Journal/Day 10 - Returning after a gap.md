---
record_class: "demonstration"
title: "Day 10 - Returning after a gap"
kind: "daily"
record_id: "demo-journal-day-10-returning-after-a-gap"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 10"
status: "fictional restart recorded"
---
# Day 10 - Returning after a gap

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Selected thread
Ellis returns to [[Demonstration/Sound/Harbour sound map]] after several unrecorded days.

## Recovery
The handoff identifies the quiet-take check, not a need to reread every daily note. Ellis notices there is no audio file in this teaching package and records the missing evidence instead of claiming progress.

## No silent scope expansion
No request is sent to Kit. No task from Rowan's seed project is imported. Days 06–09 remain unrecorded.

## First useful action
Clarify what evidence would be needed to run the check. The interruption is recovered even though the underlying project is not finished.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: demonstration
commitment_scope: fictional
scenario_id: onboarding-rehearsal
kind: daily
record_id: demo-manual-onboarding-workbook
title: Fictional manual rehearsal
---
# Fictional manual rehearsal

> FICTIONAL REHEARSAL — invented test answers, never your real commitments.

You save this workbook yourself. Leave unanswered slots blank or write “skipped”. Save and reopen after each answer. The assistant does not promise an atomic write.

## Answer 1

## Answer 2

## Answer 3

## Answer 4

## Answer 5

## Next question and pause point

## Links
[[Setup/Operator walkthrough]] · [[CONTINUE MANUALLY]] · [[HOME]]

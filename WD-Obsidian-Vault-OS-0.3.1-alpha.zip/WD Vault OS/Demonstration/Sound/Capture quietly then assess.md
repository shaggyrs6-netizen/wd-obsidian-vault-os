---
record_class: "demonstration"
title: "Capture quietly then assess"
kind: "decision"
record_id: "demo-sound-capture-quietly-then-assess"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 04"
status: "current trial decision"
---
# Capture quietly then assess

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Decision
For the next fictional comparison, use the quieter take and assess it before changing the level for presentation.

## Why
[[Demonstration/Sound/Bell capture observations]] reports a problem with Take A. [[Demonstration/Sound/Leave room for the unexpected]] explains the provisional reasoning.

## Check before accepting
Listen for clipping, distracting background noise and whether the intended sound remains clear. The packaged example cannot run that audio test because it has no audio files.

## Next action
Use [[Demonstration/Sound/Clipping check result]] to record a real result only if actual test material is later supplied in a separately authorised task.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

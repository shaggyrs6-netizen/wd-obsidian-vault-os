---
record_class: "demonstration"
title: "Leave room for the unexpected"
kind: "knowledge"
record_id: "demo-sound-leave-room-for-the-unexpected"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 04"
status: "working hypothesis"
---
# Leave room for the unexpected

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Working lesson in the story
An irreversible error during capture can matter more than an adjustable level afterwards. Ellis chooses to leave more room for unexpected peaks in the next fictional test.

## Basis and limits
[[Demonstration/Sound/Bell capture observations]] is synthetic. No waveform or playback is available here. This note teaches source-linked reasoning; it does not validate recording settings.

## Applied in
[[Demonstration/Sound/Capture quietly then assess]] and [[Demonstration/Sound/Listening note draft]].


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

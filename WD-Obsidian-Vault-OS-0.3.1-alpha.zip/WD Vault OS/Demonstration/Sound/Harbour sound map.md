---
record_class: "demonstration"
title: "Harbour sound map"
kind: "project"
record_id: "demo-sound"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "test in progress"
---
# Harbour sound map

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Outcome
Ellis wants a short fictional listening trail that pairs three ordinary sounds with a hand-drawn map. The project is independent of the seed library.

## Current state — after Scenario Day 05
A first bell recording clipped in the invented trial. A quieter take was made in the story but has not passed the listening checklist. The new plan favours a quiet capture with separate level adjustment later.

## Next action
Compare the quiet take against [[Demonstration/Sound/Clipping check result]]. Do not invent an audio test result: this package contains text descriptions, not actual recordings.

## Blocker
Permission to record a rehearsal is not confirmed. Kit cannot grant it on behalf of everyone. No outreach or recording is authorised.

## Decisions and evidence
[[Demonstration/Sound/Bell capture observations]] · [[Demonstration/Sound/Capture quietly then assess]] · [[Demonstration/Sound/Recording permission conversation]]

## Resume
[[Demonstration/Sound/Pause after the clipping test]] is the current pickup. [[Demonstration/Sound/Listening note draft]] explains the idea for a future audience.

```wd-view
{"scope": "demonstration", "project_id": "demo-sound"}
```


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: "demonstration"
title: "Kit Alder"
kind: "person"
record_id: "demo-sound-kit-alder"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 01"
status: "fictional contact"
---
# Kit Alder

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Fictional role
Kit helps coordinate a rehearsal room in the invented sound-map story.

## Relevant conversation
[[Demonstration/Sound/Recording permission conversation]]. Kit can explain the booking process but cannot give recording consent for every participant.

## Follow-up
Clarify the correct permission process if Ellis chooses to pursue that sound. No real person or message destination exists.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

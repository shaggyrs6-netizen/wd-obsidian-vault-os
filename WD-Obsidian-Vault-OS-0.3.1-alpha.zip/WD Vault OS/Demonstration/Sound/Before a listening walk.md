---
record_class: "demonstration"
title: "Before a listening walk"
kind: "routine"
record_id: "demo-sound-before-a-listening-walk"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 05"
status: "fictional routine"
---
# Before a listening walk

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Fictional reusable checklist
Use before a listening walk, not on a schedule.

- [ ] Check that the selected material is cleared for its intended use.
- [ ] Confirm a comfortable playback level.
- [ ] Carry a short note of what needs checking.
- [ ] Stop if permission or equipment is uncertain.

## Last test
Not run in this package. The unchecked boxes are demonstration content, not your tasks.

[[Demonstration/Sound/Harbour sound map]]


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

---
record_class: "demonstration"
title: "A map you can listen to"
kind: "capture"
record_id: "demo-sound-a-map-you-can-listen-to"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 01"
status: "processed"
---
# A map you can listen to

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

Ellis imagines a short route where a visitor can stop, look and listen. The first capture asks whether three small sounds are enough to make a coherent trail.

It becomes [[Demonstration/Sound/Harbour sound map]], not an obligation to create a whole exhibition.


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

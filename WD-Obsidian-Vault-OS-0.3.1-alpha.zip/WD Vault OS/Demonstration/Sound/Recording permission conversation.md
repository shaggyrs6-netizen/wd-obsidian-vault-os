---
record_class: "demonstration"
title: "Recording permission conversation"
kind: "conversation"
record_id: "demo-sound-recording-permission-conversation"
project_id: "demo-sound"
scenario_id: "harbour-sound-map"
commitment_scope: "fictional"
created: "Scenario Day 02"
status: "permission unresolved"
---
# Recording permission conversation

> [!example] FICTIONAL DEMONSTRATION
> These people, events, sources and tasks are invented. Scenario days are not calendar dates. Nothing here is your commitment or authority to contact anyone.

## Synthetic conversation
Ellis asks [[Demonstration/Sound/Kit Alder]] whether a rehearsal could supply one sound for the trail. Kit says room access and permission to record participants are separate questions.

## What remains open
The permission process has not been completed. The project can continue testing non-personal invented sounds in the demonstration without claiming consent.

## Next action in the story
Choose whether the rehearsal sound is necessary before asking for further permissions. This is not authorisation to contact anyone.

[[Demonstration/Sound/Harbour sound map]]


[[DEMONSTRATION|Fictional tour]] · [[Demonstration/Switch projects|Switch projects]] · [[HOME|Your real home]]

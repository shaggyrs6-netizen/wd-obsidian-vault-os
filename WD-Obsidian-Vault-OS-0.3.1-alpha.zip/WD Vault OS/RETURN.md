---
record_class: "system"
title: "Return to work"
---
# Return to work

If onboarding paused, use [[START WITH CLAUDE]] or [[START WITH CODEX]] and its resume prompt. For manual notes, open [[MY FIRST NOTES]].

[[Setup/Handoff chronology]] explains timestamp ordering and warnings. Do not infer the latest relevant state from a date-only record or alphabetical filename.

Choose the project you mean. Read its current decision, blocker and next action before opening an older handoff.


```wd-view
{"scope": "user", "kind": "project"}
```

## Your recent handoffs

```wd-view
{"scope": "user", "kind": "handoff"}
```

If the plugin is disabled, open [[Projects/Project desk]] and select a note in the Projects folder; then follow its handoff links. [[System/Manual creation]] explains adding a handoff link.

## If you missed several days
No catch-up marathon. Check whether the last decision is still valid, whether the blocker remains, and what one action is possible now. Record the uncovered period as unknown, not as inactivity. [[System/Return after a gap]] gives the exact procedure.

## Practise switching without mixing
[[Demonstration/Switch projects|Switch between two fictional projects]]. Real records never inherit their tasks.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

# WD Vault OS — assistant entry

Read AI/START.md and AI/Permission policy.md before working. The current user request governs scope. Default read-only; do not change these instructions yourself. Demonstration/ is fictional, never the user's commitments. Select one project ID and reconcile its current state with dated evidence. Do not infer access, memory, permission or successful saving from a written instruction. No external action without explicit approval.

Read the appropriate workflow only; do not ingest the whole vault. No secrets or sensitive prose belong in external tool calls without permission. If the host does not auto-discover this file, the user must explicitly supply it.

---
record_class: "system"
title: "Capture desk"
---
# Capture desk

Save it before sorting it. Later choose whether it becomes work, knowledge, a source or something to leave alone.


```wd-action
{"action": "capture", "label": "New capture"}
```

```wd-view
{"scope": "user", "kind": "capture"}
```

## Without the plugin
Create a note in `Capture/` and insert [[System/Templates/Capture|the capture template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/An unused shelf]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

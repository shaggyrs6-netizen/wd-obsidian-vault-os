---
record_class: system
title: "Recent notes"
---
# Recent notes

Looking for something you just made or changed? Open it from this list. The newest change is first.

![[System/Recent notes.base#Recent notes]]

These times come from the files on this computer. A changed time does not mean the work is finished. The list leaves out templates, system guides and the worked fictional tour. If you used fictional setup, its rehearsal notes appear here marked **fictional**.

If a note is missing, use [[FIND|Find something]] or Obsidian’s Search. The list needs Obsidian’s built-in Bases feature; it does not need a community plugin.

[[AFTER SETUP|What to do next]] · [[HOME|Home]] · [[RETURN|Return to work]]

---
record_class: "system"
title: "Everyday desk"
---
# Everyday desk

Practical reference, errands and responsibilities can stay small. Dates do not create external reminders.


```wd-action
{"action": "everyday", "label": "New everyday"}
```

```wd-view
{"scope": "user", "kind": "everyday"}
```

## Without the plugin
Create a note in `Everyday/` and insert [[System/Templates/Everyday|the everyday template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Return the empty containers]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

---
record_class: "system"
title: "Routine desk"
---
# Routine desk

A checklist helps with repeated situations. It becomes a dated record only when you actually use it.


```wd-action
{"action": "routine", "label": "New routine"}
```

```wd-view
{"scope": "user", "kind": "routine"}
```

## Without the plugin
Create a note in `Everyday/Routines/` and insert [[System/Templates/Routine|the routine template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Sound/Before a listening walk]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

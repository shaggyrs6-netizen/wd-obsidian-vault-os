---
record_class: "system"
title: "People desk"
---
# People desk

Keep useful context and conversations. Follow-ups are explicit choices, never manufactured social obligations.


```wd-action
{"action": "person", "label": "New person"}
```

```wd-view
{"scope": "user", "kind": "person"}
```

## Without the plugin
Create a note in `People/` and insert [[System/Templates/Person|the person template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Noor Bell]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

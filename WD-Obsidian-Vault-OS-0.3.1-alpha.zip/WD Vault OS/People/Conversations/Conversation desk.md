---
record_class: "system"
title: "Conversation desk"
---
# Conversation desk

Separate what was said, what was agreed and what you inferred. A note is not authority to contact someone.


```wd-action
{"action": "conversation", "label": "New conversation"}
```

```wd-view
{"scope": "user", "kind": "conversation"}
```

## Without the plugin
Create a note in `People/Conversations/` and insert [[System/Templates/Conversation|the conversation template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Sound/Recording permission conversation]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

# WD Vault OS — Claude entry

Read AGENTS.md, AI/START.md and AI/Permission policy.md explicitly. This file grants no extra authority or account access. Use the selected project and current user scope. Read-back must refer to this local vault, not a cloud artifact. Demonstration content is fictional and excluded from real commitments. Product procedures are guidance, not a tool sandbox.

---
record_class: "system"
title: "Source desk"
---
# Source desk

A source is what you read, heard or observed. Your interpretation belongs in a linked knowledge or writing note.

[[Sources/Readwise and AI|Optional Readwise import and AI guide]] explains how captured material can become a considered note without treating every clipping as knowledge.


```wd-action
{"action": "source", "label": "New source"}
```

```wd-view
{"scope": "user", "kind": "source"}
```

## Without the plugin
Create a note in `Sources/` and insert [[System/Templates/Source|the source template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Trial observations]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

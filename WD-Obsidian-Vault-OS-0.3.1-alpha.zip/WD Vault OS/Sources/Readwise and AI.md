---
record_class: system
title: "Readwise and AI"
---
# Readwise and AI

**Optional.** Readwise is a capture and highlight service. Its official Obsidian plugin can copy highlights into this vault. It needs a Readwise account and your permission; setup does not install it, sign in, sync, or send vault notes to Readwise.

## Connect it if you choose

1. In Obsidian, open **Settings → Community plugins → Browse** and select **Readwise Official**. Install and enable it yourself.
2. Open the plugin settings and connect your own Readwise account. Set its **base folder** to `Sources/Readwise` before the first sync. Choose manual sync to begin with, so you can inspect the first import.
3. Use **Initiate Sync** in the plugin settings or **Readwise Official: Sync your data now** in Obsidian's command palette. Check one imported note and its source link before leaving automatic sync on.

Readwise's current guide: https://docs.readwise.io/highlights/docs/exporting-highlights/obsidian . Read the current instructions in the app if labels differ. New highlights are appended; edits to a highlight in Readwise do not automatically rewrite the existing exported highlight. Moving or renaming an imported file can make Readwise create another one later, so leave imported files in the plugin's folder. Full Reader document export is a separate option and can bring much more material into the vault; leave it off unless you want that scope.

## What the assistant may do

An import is **source material**, not a belief or a completed reading task. Ask the assistant to show one source's title, author, URL, date if present, and a short account of the useful parts. Choose **drop, read, think, or keep**. For **keep**, ask for a separate note in your own words linked to the source and a relevant project. Approve that note and path before it is saved. Do not rewrite the Readwise-owned file or bulk-process a backlog without asking.

If an assistant cannot access this local vault, it cannot claim to have read the imported note. Never paste account tokens into chat or a note.

[[Sources/Source desk|Sources]] · [[AI/Source to knowledge|Source to knowledge]] · [[HOME|Home]]

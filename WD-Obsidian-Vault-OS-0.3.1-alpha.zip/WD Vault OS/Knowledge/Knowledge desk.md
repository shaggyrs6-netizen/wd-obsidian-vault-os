---
record_class: "system"
title: "Knowledge desk"
---
# Knowledge desk

Keep explanations worth using again. Connect claims to sources, record limits and preserve changes of mind.


```wd-action
{"action": "knowledge", "label": "New knowledge"}
```

```wd-view
{"scope": "user", "kind": "knowledge"}
```

## Without the plugin
Create a note in `Knowledge/` and insert [[System/Templates/Knowledge|the knowledge template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Organise around the first question]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

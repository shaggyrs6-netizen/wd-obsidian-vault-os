---
record_class: "system"
title: "Topic desk"
---
# Topic desk

A small guide links ideas, questions and useful sources. It helps navigation without requiring you to classify everything.


```wd-action
{"action": "topic", "label": "New topic"}
```

```wd-view
{"scope": "user", "kind": "topic"}
```

## Without the plugin
Create a note in `Knowledge/Topics/` and insert [[System/Templates/Topic|the topic template]] using core Templates. [[System/Manual creation|Exact steps and metadata]].

## A completed fictional example
[[Demonstration/Seed/Helping a newcomer choose]] — demonstration only.

[[HOME|Home]] · [[RETURN|Return to work]] · [[FIND|Find something]] · [[DEMONSTRATION|Fictional tour]]

# WD Obsidian Vault OS 0.3.1 alpha — change record

This distribution is built from the byte-checked 0.3.0 candidate. The setup engine, WD Actions plugin, templates, examples and Obsidian configuration are unchanged. This revision corrects distribution and third-party theme wording, updates the product label and version on the start page, and keeps the technical vault folder name `WD Vault OS` so existing setup links still match.

Prism 3.8.0 remains optional and disabled by default. Its MIT and embedded-font notices remain inside the vault. Readwise and Style Settings are not bundled or connected. No AI assistant, schedule or automatic import is included.

The previous ZIP and every earlier candidate remain intact. The builder and per-entry manifest are retained separately from this distribution.

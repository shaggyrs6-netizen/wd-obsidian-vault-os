# WD Obsidian Vault OS 0.3.1 alpha — verification scope

The new distribution is a documentation correction of the pinned 0.3.0 candidate. Its engine, plugin, templates and examples are unchanged. The builder records a SHA-256 digest for the ZIP and every entry, refuses a changed source ZIP, and checks ZIP CRC and read-back. Platform smoke-test results are published with the GitHub release.

Windows and macOS automated checks cover extraction, the local setup helper, fictional progress and pause/resume, four starter-note outputs, links and package identity. They do **not** prove that a person can find their way in Obsidian, that a desktop AI assistant has local-folder access, or that the theme and Recents view render correctly in every Obsidian version. Those are alpha feedback questions.

The manual route needs no Node installation. The optional automatic helper needs an existing local Node runtime against the extracted original folder. The package never assumes that a cloud shell or uploaded ZIP can write to a person's computer.

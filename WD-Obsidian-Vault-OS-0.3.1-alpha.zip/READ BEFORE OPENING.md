# WD Obsidian Vault OS 0.3.1 alpha

This is an early test build. Extract the ZIP into a new folder and open `START HERE.html`. The inner folder is still named `WD Vault OS` for compatibility with this version's setup links; open that inner folder as the vault in Obsidian. Keep it separate from any vault you already use.

Start with fictional answers. Choose Codex, Claude or the manual route. An assistant must check whether it can actually access the extracted local folder before claiming to save anything. No account or Readwise connection is required. The package does not install Obsidian, activate a theme, schedule notes or publish work.

The package contains generic guides, fictional examples, original WD Actions code and the optional Prism theme with its licences. It contains no notes, settings, credentials, Readwise exports or private material from Lee's live vault. See `WD Vault OS/System/Use and provenance.md` and `WD Vault OS/System/Third-party credits.md`.

The included `ACCEPTANCE.md` describes what automated checks cover and what still needs human testing. Please report where you get stuck; this is the purpose of an alpha.
